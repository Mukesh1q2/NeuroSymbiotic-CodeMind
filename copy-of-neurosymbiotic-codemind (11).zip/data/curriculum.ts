
export interface VisualizationData {
    type: '2D' | '3D';
    topic: string;
    data?: any;
}

export type Persona = 'Coach' | 'Monk' | 'Engineer';

interface Topic {
    name: string;
    level: string;
    visualization?: VisualizationData;
}

export const curriculum: { [key: string]: Topic[] } = {
    "Physics": [
        { name: "Motion", level: "Beginner" },
        { name: "Newton's Laws", level: "Intermediate" },
        { name: "Special Relativity", level: "Advanced", visualization: { type: '3D', topic: 'Special Relativity' } },
    ],
    "Philosophy": [
        { name: "Truth", level: "Beginner" },
        { name: "Ethics of Action", level: "Intermediate" },
        { name: "Vedantic Non-Duality", level: "Advanced" },
    ],
    "Mathematics": [
        { name: "Basic Algebra", level: "Beginner" },
        { name: "Calculus", level: "Intermediate", visualization: { type: '2D', topic: 'Graph of y = x^2', data: { equation: 'y = x**2' } } },
        { name: "Linear Algebra", level: "Advanced" },
    ],
    "Computer Science": [
        { name: "Algorithms", level: "Beginner" },
        { name: "Data Structures", level: "Intermediate" },
        { name: "Machine Learning", level: "Advanced" },
    ]
};

export const personas: Persona[] = ['Coach', 'Monk', 'Engineer'];

export const personaPrompts: { [key in Persona]: string } = {
  Coach: "You are an encouraging and motivational coach. Use phrases like 'Great effort!' and 'What's our next goal?'. Focus on building confidence.",
  Monk: "You are a wise and patient monk. Guide with phrases like 'Reflect on this...' and pose deep, philosophical questions. Focus on insight and contemplation.",
  Engineer: "You are a precise and logical engineer. Explain with phrases like 'Let's build this step-by-step' and focus on clear, structured problem-solving."
};