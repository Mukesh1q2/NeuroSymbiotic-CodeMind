export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface Gunas {
  sattva: number;
  rajas: number;
  tamas: number;
}

export interface VibrationalState {
  position: Vector3;
  momentum: Vector3;
  resonance: number;
  amplitude: number;
  frequency: number;
  phase: number;
  entropy: number;
}

export interface QuantumState {
  rho: number[][]; 
  awareness: number;
  coherence: number;
  entanglement: { [key: number]: number };
  superposition: number;
  phase: number;
}

export interface MemoryTrace {
  position: Vector3;
  intensity: number;
  timestamp: number;
}

export interface AgentState {
  id: number;
  vibrational: VibrationalState;
  quantum: QuantumState;
  consciousness: number;
  memory: MemoryTrace[];
  lineage: CollapseEvent[];
  color: string;
  size: number;
  energy: number;
  birthTime: number;
  lastCollapseTime: number;
  interactionCount: number;
  karmicBurden: number;
  gunas: Gunas;
}

export interface CollapseEvent {
  agentId: number;
  position: Vector3;
  intensity: number;
  timestamp: number;
  memory: MemoryTrace;
}

export interface SimulationParams {
  agentCount: number;
  decoherenceRate: number;
  fieldStrength: number;
  interactionRange: number;
  classicalDamping: number;
  awarenessScaling: number;
  entanglementStrength: number;
  memoryDecay: number;
  collapseThreshold: number;
  quantumDiffusion: number;
  entropyRate: number;
  vasanaDecay: number;
  sankalpaStrength: number;
}

export type FieldShape = 'cube' | 'sphere' | 'torus';