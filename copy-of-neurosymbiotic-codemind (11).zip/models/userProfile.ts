
import type { Persona } from '../data/curriculum';

export interface UserProfile {
    age: number;
    persona: Persona;
    karmaPoints: number;
    karmaHistory: number[];
    progress: { [key: string]: string };
}

const defaultProfile: UserProfile = {
    age: 16,
    persona: 'Coach',
    karmaPoints: 0,
    karmaHistory: [0],
    progress: {},
};

export const loadUserProfile = (): UserProfile => {
    try {
        const savedProfile = localStorage.getItem('sarasvatiq_user_profile');
        if (savedProfile) {
            const parsed = JSON.parse(savedProfile);
            // Ensure karmaHistory is initialized if it's missing from older saves
            if (!parsed.karmaHistory || !Array.isArray(parsed.karmaHistory) || parsed.karmaHistory.length === 0) {
                parsed.karmaHistory = [parsed.karmaPoints || 0];
            }
            return { ...defaultProfile, ...parsed };
        }
    } catch (error) {
        console.error("Failed to load user profile:", error);
    }
    return defaultProfile;
};

export const saveUserProfile = (profile: UserProfile): void => {
    try {
        localStorage.setItem('sarasvatiq_user_profile', JSON.stringify(profile));
    } catch (error) {
        console.error("Failed to save user profile:", error);
    }
};
