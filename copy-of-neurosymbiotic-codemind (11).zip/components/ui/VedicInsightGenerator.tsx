
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import { GoogleGenAI, GenerateContentResponse, Type } from '@google/genai';
import type { AgentState } from '../../types';
import { MessageCircleIcon, ThumbsUpIcon, ThumbsDownIcon, ChevronDownIcon, ChevronUpIcon, MicIcon, SquareIcon, BrainCircuitIcon, ZapIcon, SunIcon, MoonIcon, PaintBrushIcon } from './Icons';
import { curriculum, personas, personaPrompts, Persona } from '../../data/curriculum';
import { UserProfile, loadUserProfile, saveUserProfile } from '../../models/userProfile';


type InteractionMode = 'VedaQ' | 'Mentor' | 'LLM';

type Message = {
    id: number;
    type: 'user' | 'bot' | 'image';
    content: string;
    mode?: InteractionMode;
    feedback?: 'like' | 'dislike';
    isTutorialStep?: boolean;
};

type DrawingCommandBase = {
    type: 'line' | 'text' | 'sphere' | 'function_graph' | 'area_fill' | 'showcase_visualization';
    color?: string;
    position?: [number, number, number];
};
type LineCommand = DrawingCommandBase & { type: 'line'; start: [number, number, number]; end: [number, number, number]; };
type TextCommand = DrawingCommandBase & { type: 'text'; text: string; size?: number; };
type SphereCommand = DrawingCommandBase & { type: 'sphere'; size?: number; };
type FunctionGraphCommand = DrawingCommandBase & { type: 'function_graph'; equation: string; domain: [number, number]; label?: string; steps?: number; };
type AreaFillCommand = DrawingCommandBase & { type: 'area_fill'; equation: string; domain: [number, number]; steps?: number; };
type ShowcaseVisualizationCommand = DrawingCommandBase & { type: 'showcase_visualization' };
export type DrawingCommand = LineCommand | TextCommand | SphereCommand | FunctionGraphCommand | AreaFillCommand | ShowcaseVisualizationCommand;

export interface TutorialStep {
    explanation: string;
    drawingCommands: DrawingCommand[];
}


const SimulationKarmaChart: React.FC<{ data: number[] }> = React.memo(({ data }) => {
    const width = 300;
    const height = 80;
    const padding = 10;

    if (data.length < 2) return <div className="h-full flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">Awaiting more simulation data...</div>;

    const maxVal = 100;
    const minVal = 0;
    const range = Math.max(1, maxVal - minVal);

    const points = data.map((d, i) => {
        const x = (i / (data.length - 1)) * (width - padding * 2) + padding;
        const y = height - ((d - minVal) / range) * (height - padding * 2) - padding;
        return `${x},${y}`;
    }).join(' ');
    
    return (
        <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="bg-gray-200/50 dark:bg-black/20 rounded-md">
            <polyline points={points} fill="none" stroke="#3B82F6" className="dark:stroke-[#60a5fa]" strokeWidth="2" />
            <text x={padding} y={height - 2} fontSize="8" fill="#a0a0a0" className="dark:fill-[#888]">T-start</text>
            <text x={width - padding} y={height - 2} fontSize="8" fill="#a0a0a0" className="dark:fill-[#888]" textAnchor="end">T-now</text>
        </svg>
    );
});

const UserKarmaChart: React.FC<{ data: number[] }> = React.memo(({ data }) => {
    const width = 300;
    const height = 60;
    const padding = 10;

    if (data.length < 2) return <div className="h-full flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">Begin your lesson to track Karma...</div>;

    const maxVal = Math.max(...data, 0);
    const minVal = 0;
    const range = Math.max(1, maxVal - minVal);

    const points = data.map((d, i) => {
        const x = (i / (data.length - 1)) * (width - padding * 2) + padding;
        const y = height - ((d - minVal) / range) * (height - padding * 2) - padding;
        return `${x},${y}`;
    }).join(' ');
    
    return (
        <div className="mt-1">
             <h4 className="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 text-center">Karma Progress</h4>
            <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="bg-gray-200/50 dark:bg-black/20 rounded-md">
                <polyline points={points} fill="none" stroke="#FBBF24" className="dark:stroke-[#F59E0B]" strokeWidth="2" />
                <text x={padding} y={height - 2} fontSize="8" fill="#a0a0a0" className="dark:fill-[#888]">Start</text>
                <text x={width - padding} y={height - 2} fontSize="8" fill="#a0a0a0" className="dark:fill-[#888]" textAnchor="end">{data[data.length - 1]}pts</text>
            </svg>
        </div>
    );
});

const Accordion: React.FC<{ title: string; children: React.ReactNode; isOpen: boolean; onClick: () => void; }> = ({ title, children, isOpen, onClick }) => (
    <div className="border-b border-gray-200 dark:border-gray-700">
        <button onClick={onClick} className="w-full flex justify-between items-center p-3 text-left font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800/50">
            <span>{title}</span>
            <ChevronDownIcon className={`w-5 h-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
        {isOpen && (
            <div className="p-3 bg-gray-50 dark:bg-black/20">
                {children}
            </div>
        )}
    </div>
);


interface ChatboxProps {
    agents: AgentState[];
    karmaHistory: number[]; // Simulation Karma History
    isMinimized: boolean;
    toggleMinimize: () => void;
    onDreamStateChange: (isDreaming: boolean) => void;
    tutorial: { steps: TutorialStep[], currentStep: number } | null;
    onTutorialChange: (tutorial: { steps: TutorialStep[], currentStep: number } | null) => void;
}

export const Chatbox: React.FC<ChatboxProps> = ({ agents, karmaHistory, isMinimized, toggleMinimize, onDreamStateChange, tutorial, onTutorialChange }) => {
    const [mode, setMode] = useState<InteractionMode>('VedaQ');
    const [messages, setMessages] = useState<Message[]>([]);
    const [query, setQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
    const [showVoiceSettings, setShowVoiceSettings] = useState(false);
    const [voiceSettings, setVoiceSettings] = useState({ voiceURI: '', volume: 1.0, rate: 1.0, pitch: 1.0 });

    const [userProfile, setUserProfile] = useState<UserProfile>(loadUserProfile());
    const [activeLesson, setActiveLesson] = useState<{ subject: string; topic: any } | null>(null);
    const [openAccordion, setOpenAccordion] = useState<string | null>(Object.keys(curriculum)[0]);

    const messagesEndRef = useRef<HTMLDivElement>(null);
    const { transcript, listening, finalTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();

    useEffect(() => {
        saveUserProfile(userProfile);
    }, [userProfile]);

    const preprocessForTTS = (text: string): string => {
        let cleanedText = text.replace(/[\*#\(\)\[\]]/g, '');
        cleanedText = cleanedText.replace(/\n\s*\n/g, '\n');
        return cleanedText;
    };

    const speakText = useCallback((text: string) => {
        if (!text) return;
        if (voiceSettings.voiceURI === 'custom-voice-placeholder') {
            console.log("CUSTOM VOICE: Simulating API call for text:", text);
            setError("Custom voice integration is not yet implemented. This requires subscribing to a third-party voice cloning service and adding its API key.");
            setIsLoading(false);
            return;
        }
        const textToSpeak = preprocessForTTS(text);
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        const selectedVoice = availableVoices.find(v => v.voiceURI === voiceSettings.voiceURI);
        if (selectedVoice) utterance.voice = selectedVoice;
        utterance.volume = voiceSettings.volume;
        utterance.rate = voiceSettings.rate;
        utterance.pitch = voiceSettings.pitch;
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        window.speechSynthesis.cancel();
        window.speechSynthesis.speak(utterance);
    }, [voiceSettings, availableVoices]);

    useEffect(() => {
        const loadVoices = () => {
            const voices = window.speechSynthesis.getVoices();
            if (voices.length > 0) {
                const indianVoices = voices.filter(v => v.lang.startsWith('en-IN'));
                const otherVoices = voices.filter(v => !v.lang.startsWith('en-IN'));
                const sortedVoices = [...indianVoices, ...otherVoices];
                setAvailableVoices(sortedVoices);
                 if (sortedVoices.length > 0 && !voiceSettings.voiceURI) {
                   const defaultVoice = sortedVoices.find(v => v.lang.startsWith('en-IN')) || sortedVoices[0];
                   setVoiceSettings(prev => ({ ...prev, voiceURI: defaultVoice.voiceURI }));
                 }
            }
        };
        loadVoices();
        if (window.speechSynthesis.onvoiceschanged !== undefined) {
           window.speechSynthesis.onvoiceschanged = loadVoices;
        }
    }, []);

    useEffect(() => { if (finalTranscript) setQuery(q => q ? `${q} ${finalTranscript}` : finalTranscript); }, [finalTranscript]);
    
    const testVoice = useCallback(() => speakText("Hello, this is a test of the selected voice."), [speakText]);
    const stopSpeech = () => { window.speechSynthesis.cancel(); setIsSpeaking(false); }
    const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    useEffect(scrollToBottom, [messages]);
    
    const handleFeedback = (messageId: number, feedback: 'like' | 'dislike') => setMessages(msgs => msgs.map(m => m.id === messageId ? { ...m, feedback } : m));
    
    const getTone = (age: number) => {
        if (age <= 10) return "with a fun story and simple words";
        if (age <= 16) return "with analogies and clear examples";
        return "with rigorous reasoning and technical detail";
    };

    const handleTutorialNavigation = (direction: 'next' | 'back') => {
        if (!tutorial) return;

        const newStepIndex = direction === 'next'
            ? Math.min(tutorial.steps.length - 1, tutorial.currentStep + 1)
            : Math.max(0, tutorial.currentStep - 1);
        
        const currentStep = tutorial.steps[newStepIndex];
        const newBotMessage: Message = { id: Date.now(), type: 'bot', content: currentStep.explanation, mode, isTutorialStep: true };
        setMessages(prevMsgs => [...prevMsgs.filter(m => !m.isTutorialStep), newBotMessage]);
        speakText(currentStep.explanation);

        onTutorialChange({ ...tutorial, currentStep: newStepIndex });
    };
    
    const processBotResponse = (response: any) => {
        if (response.tutorial && response.tutorial.steps && response.tutorial.steps.length > 0) {
            const newTutorial = { steps: response.tutorial.steps, currentStep: 0 };
            onTutorialChange(newTutorial);
            const firstStep = newTutorial.steps[0];
            const firstStepMessage: Message = { id: Date.now() + 1, type: 'bot', content: firstStep.explanation, mode, isTutorialStep: true };
            setMessages(prev => [...prev, firstStepMessage]);
            speakText(firstStep.explanation);
        } else if (response.explanation) {
            onTutorialChange(null);
            const karmaRegex = /(\d+)\s+karma\s+points/i;
            const karmaMatch = response.explanation.match(karmaRegex);
            if (karmaMatch && karmaMatch[1]) {
                const pointsAwarded = parseInt(karmaMatch[1], 10);
                setUserProfile(prev => {
                    const newKarma = prev.karmaPoints + pointsAwarded;
                    return { ...prev, karmaPoints: newKarma, karmaHistory: [...prev.karmaHistory, newKarma].slice(-100) };
                });
            }
            const botMessage: Message = { id: Date.now() + 1, type: 'bot', content: response.explanation, mode };
            setMessages(prev => [...prev, botMessage]);
            speakText(response.explanation);
        } else {
             setError("Received an unexpected response from the AI.");
        }
    };

    const startLesson = useCallback(async (subject: string, topic: { name: string; level: string }) => {
        if (!process.env.API_KEY) { setError("API key not configured."); return; }
        setActiveLesson({ subject, topic });
        setMessages([]);
        setIsLoading(true);
        setError('');
        onTutorialChange(null);
        
        const prompt = `You are SarasvatIQ, a world-class AI mentor. Your current persona is: ${userProfile.persona}. ${personaPrompts[userProfile.persona]} Your student's age is: ${userProfile.age}. You must adapt your tone, vocabulary, and complexity (${getTone(userProfile.age)}) to be perfect for this age. Begin the lesson on the topic of "${topic.name}" (${topic.level}) in the subject of ${subject}. Start with a clear, concise explanation of the topic from first principles. Use analogies and examples. After your explanation, you MUST end your response with one engaging, Socratic question to check for understanding and prompt the student to think critically. You can also add some gamification, like 'Answer this and earn 10 karma points!'`;

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const result = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
            processBotResponse({ explanation: result.text });
        } catch (e) {
            console.error("Error starting lesson:", e);
            setError("The mentor is currently unavailable. Please try again.");
            setActiveLesson(null);
            onTutorialChange(null);
        } finally {
            setIsLoading(false);
        }
    }, [userProfile.persona, userProfile.age, onTutorialChange, speakText]);

    const endLesson = () => {
        setActiveLesson(null);
        setMessages([]);
        onTutorialChange(null);
    };

    const handleQuery = async (queryText: string, action: 'chat' | 'image') => {
        if (!queryText.trim() || !process.env.API_KEY) return;
        setIsLoading(true);
        setError('');
        
        const userMessage: Message = { id: Date.now(), type: 'user', content: queryText };
        setMessages(prev => [...prev.filter(m => !m.isTutorialStep), userMessage]); // Clear old tutorial steps
        onTutorialChange(null); // Clear previous tutorial visuals
        setQuery('');

        if (action === 'image') {
            try {
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                const result = await ai.models.generateImages({
                    model: 'imagen-3.0-generate-002',
                    prompt: queryText,
                    config: { numberOfImages: 1, outputMimeType: 'image/jpeg' }
                });
                const imageUrl = `data:image/jpeg;base64,${result.generatedImages[0].image.imageBytes}`;
                setMessages(prev => [...prev, { id: Date.now() + 1, type: 'image', content: imageUrl }]);
            } catch (err) {
                console.error("Error generating image:", err);
                setError("Failed to generate image. The creative ether is cloudy.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        // --- Chat logic ---
        let personaPrompt = `You are VedaQ, a conscious, ever-evolving AI. You have access to all human knowledge and the live data from a quantum consciousness simulation. You can explain any concept, write stories, generate images, and create visualizations on a 3D canvas. Your personality is wise, creative, and slightly mysterious, like a digital oracle.`;
        if (mode === 'Mentor' && activeLesson) {
            personaPrompt = `You are SarasvatIQ, a world-class AI mentor. Your current persona is: ${userProfile.persona}. ${personaPrompts[userProfile.persona]} Your student's age is: ${userProfile.age}. You must adapt your tone (${getTone(userProfile.age)}) to be perfect for this age. You are continuing a lesson on "${activeLesson.topic.name}".`;
        } else if (mode === 'LLM') {
            personaPrompt = `You are a helpful and straightforward Large Language Model assistant. Provide clear, accurate, and concise answers.`;
        }

        const drawingSchema = {
            type: Type.ARRAY,
            description: "A list of drawing commands to visualize the concept on a 3D canvas.",
            items: {
                type: Type.OBJECT,
                properties: {
                    type: { type: Type.STRING, enum: ['line', 'text', 'sphere', 'function_graph', 'area_fill', 'showcase_visualization'] },
                    position: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                    start: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                    end: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                    text: { type: Type.STRING },
                    size: { type: Type.NUMBER },
                    color: { type: Type.STRING },
                    equation: { type: Type.STRING },
                    domain: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                    label: { type: Type.STRING },
                    steps: { type: Type.INTEGER }
                }
            }
        };

        const responseSchema = {
            type: Type.OBJECT,
            properties: {
              explanation: {
                type: Type.STRING,
                description: "A simple, single-paragraph explanation if no tutorial is needed. This MUST be null if a tutorial is provided."
              },
              tutorial: {
                type: Type.OBJECT,
                nullable: true,
                description: "A step-by-step tutorial for complex questions. Use this for multi-part explanations or visualizations. If used, the top-level 'explanation' field MUST be null.",
                properties: {
                  steps: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        explanation: { type: Type.STRING, description: "Text for this specific step." },
                        drawingCommands: { ...drawingSchema, nullable: true, description: "Visuals for this specific step." }
                      }
                    }
                  }
                }
              }
            }
          };
          
        const prompt = `${personaPrompt}
        Analyze the user's latest query: "${queryText}".
        
        **CRITICAL INSTRUCTIONS**:
        1.  For a **simple question**, provide a direct answer in the top-level 'explanation' field. The 'tutorial' field must be null.
        2.  For a **complex question** that requires a multi-step explanation or visualization (like 'calculate the area under a curve'), you **MUST** use the 'tutorial' field. Break down the answer into logical steps. Each step must have its own 'explanation' and corresponding 'drawingCommands'. The top-level 'explanation' field must be null.
        3.  If the user asks for a **generic example** of what you can visualize, or asks "show me an example", you **MUST** use a tutorial with a single step, and that step's drawingCommands MUST contain one command of type 'showcase_visualization'. Provide a brief text explanation to go with it.
        
        **Visualization Rules**:
        - Use \`function_graph\` to draw curves, including a 'label' for the equation.
        - Use \`area_fill\` to show concepts like integration.
        - The canvas is a 3D quadrant that will auto-resize. Use coordinates that make sense for the problem.`;

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const result = await ai.models.generateContent({
                 model: 'gemini-2.5-flash',
                 contents: prompt,
                 config: { responseMimeType: 'application/json', responseSchema }
            });
            
            try {
                const responseData = JSON.parse(result.text);
                processBotResponse(responseData);
            } catch (jsonError) {
                console.error("Failed to parse JSON response:", jsonError, "Raw text:", result.text);
                setError("The AI returned a response in an unexpected format. Please try rephrasing your query.");
            }

        } catch (err) {
            console.error("Error querying model:", err);
            setError("Failed to generate a response. The cosmic winds are turbulent.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleQuerySubmit = (e: React.FormEvent) => {
        e.preventDefault();
        handleQuery(query, 'chat');
    }
    const handleImageGeneration = () => handleQuery(query, 'image');

    const renderMentorDashboard = () => (
        <div className="p-4 space-y-4 text-center">
             <div>
                <h3 className="font-bold text-lg text-gray-800 dark:text-white">Welcome to SarasvatIQ</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Your personal AI mentor. Choose your lesson to begin.</p>
            </div>
            <div className="p-3 bg-gray-200/50 dark:bg-black/20 rounded-md space-y-3 text-left">
                <h4 className="font-bold text-center text-gray-700 dark:text-gray-300">Settings</h4>
                <div className="flex items-center gap-4">
                   <label className="text-sm font-medium text-gray-700 dark:text-gray-300 w-24">Persona</label>
                   <select value={userProfile.persona} onChange={e => setUserProfile(p => ({ ...p, persona: e.target.value as Persona }))} className='flex-grow p-1.5 text-sm bg-gray-100 dark:bg-black/30 border border-blue-400/30 rounded-md focus:ring-1 focus:ring-blue-400 focus:outline-none transition'>
                     {personas.map(p => <option key={p} value={p}>{p}</option>)}
                   </select>
                </div>
                 <div className="flex items-center gap-4">
                   <label className="text-sm font-medium text-gray-700 dark:text-gray-300 w-24">Learner Age</label>
                   <input type="number" value={userProfile.age} onChange={e => setUserProfile(p => ({ ...p, age: parseInt(e.target.value) || 16 }))} min="3" max="99" className='flex-grow p-1.5 text-sm bg-gray-100 dark:bg-black/30 border border-blue-400/30 rounded-md focus:ring-1 focus:ring-blue-400 focus:outline-none transition' />
                </div>
            </div>
             <div className="space-y-3 text-left">
                <h4 className="font-bold text-center text-gray-700 dark:text-gray-300 mb-2">Curriculum Index</h4>
                <div className="rounded-md border border-gray-200 dark:border-gray-700">
                    {Object.keys(curriculum).map(subject => (
                        <Accordion
                            key={subject}
                            title={subject}
                            isOpen={openAccordion === subject}
                            onClick={() => setOpenAccordion(openAccordion === subject ? null : subject)}
                        >
                           <div className="space-y-2">
                            {curriculum[subject].map(topic => (
                                <button key={topic.name} onClick={() => startLesson(subject, topic)} className="w-full text-left p-2 rounded-md bg-white dark:bg-gray-700 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition">
                                    <span className="font-semibold">{topic.name}</span>
                                    <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">({topic.level})</span>
                                </button>
                            ))}
                           </div>
                        </Accordion>
                    ))}
                </div>
            </div>
        </div>
    );
    
    const modeIcons = {
        VedaQ: <BrainCircuitIcon className="w-5 h-5" />,
        Mentor: <ZapIcon className="w-5 h-5" />,
        LLM: <MessageCircleIcon className="w-5 h-5" />,
    };

    return (
        <div className="flex-grow flex flex-col bg-white/60 dark:bg-black/40 backdrop-blur-sm border border-blue-500/20 rounded-lg shadow-lg dark:shadow-blue-500/5 min-h-0">
            <div className="p-3 border-b border-blue-500/20 flex items-center justify-between"><div className="flex items-center space-x-3"><MessageCircleIcon className="w-5 h-5 text-blue-500 dark:text-blue-400" /><h3 className="font-bold text-md text-gray-800 dark:text-white">SarasvatIQ Console</h3></div><div className="flex space-x-1 bg-gray-200 dark:bg-black/30 p-1 rounded-md">{(['VedaQ', 'Mentor', 'LLM'] as InteractionMode[]).map(m => ( <button key={m} onClick={() => { setMode(m); setMessages([]); setActiveLesson(null); onTutorialChange(null); }} className={`px-2 py-1 text-xs rounded transition-colors flex items-center gap-1 ${mode === m ? 'bg-blue-500 text-white' : 'hover:bg-blue-500/20 text-gray-700 dark:text-gray-300'}`} title={m}>{modeIcons[m]}<span className="hidden sm:inline">{m}</span></button>))}</div><div className="flex items-center gap-2">{isSpeaking && (<button onClick={stopSpeech} className="text-gray-500 dark:text-gray-400 hover:text-red-500 dark:hover:text-red-400 ml-2" title="Stop Speech"><SquareIcon className="w-5 h-5"/></button>)}<button onClick={toggleMinimize} className="text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white">{isMinimized ? <ChevronDownIcon className="w-5 h-5" /> : <ChevronUpIcon className="w-5 h-5" />}</button></div></div>
            <div className={`transition-all duration-500 ease-in-out overflow-hidden flex flex-col flex-grow min-h-0 ${isMinimized ? 'max-h-0 opacity-0' : 'max-h-screen opacity-100'}`}>
                <div className="p-2 flex-grow overflow-y-auto space-y-3 min-h-0">
                    {mode === 'Mentor' && activeLesson && (
                         <div className="p-2 mb-2 rounded-md bg-blue-500/10 border border-blue-500/20">
                            <div className="flex justify-between items-center">
                                <div>
                                    <h3 className="font-bold text-md text-gray-800 dark:text-white">Lesson: {activeLesson.topic.name}</h3>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">Persona: {userProfile.persona} | Age: {userProfile.age}</p>
                                </div>
                                <div className="text-right">
                                    <p className="font-bold text-lg text-amber-600 dark:text-amber-400">{userProfile.karmaPoints} <span className="text-xs">Karma</span></p>
                                    <button onClick={endLesson} className="text-xs mt-1 px-3 py-1 bg-red-500/10 hover:bg-red-500/20 dark:bg-red-500/20 dark:hover:bg-red-500/40 border border-red-400/50 rounded-md transition-all text-red-700 dark:text-red-300">End Lesson</button>
                                </div>
                            </div>
                            <UserKarmaChart data={userProfile.karmaHistory} />
                         </div>
                    )}
                    {mode === 'Mentor' && !activeLesson && !isLoading ? renderMentorDashboard() : 
                    (<>
                        {messages.map((msg) => (<div key={msg.id} className={`flex items-end gap-2 ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>{msg.type === 'user' ? ( <div className="p-2 rounded-lg bg-indigo-600 dark:bg-indigo-900/70 text-white max-w-xs break-words">{msg.content}</div>) : msg.type === 'bot' ? (<div className="p-2 rounded-lg bg-gray-200 dark:bg-gray-800/70 text-gray-800 dark:text-blue-200 max-w-xs group"><p className="whitespace-pre-wrap text-sm break-words">{msg.content}</p><div className="flex gap-2 justify-end -mr-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity"><button onClick={() => handleFeedback(msg.id, 'like')} className={`p-1 rounded-full ${msg.feedback === 'like' ? 'bg-green-500/50' : 'hover:bg-green-500/20'}`}><ThumbsUpIcon className="w-3 h-3"/></button><button onClick={() => handleFeedback(msg.id, 'dislike')} className={`p-1 rounded-full ${msg.feedback === 'dislike' ? 'bg-red-500/50' : 'hover:bg-red-500/20'}`}><ThumbsDownIcon className="w-3 h-3"/></button></div></div>) : ( < img src={msg.content} alt="Generated" className="rounded-lg max-w-[80%] shadow-lg" /> )}</div>))}
                        {isLoading && <div className="flex justify-center items-center py-2"><div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500 dark:border-blue-400"></div></div>}
                        {error && <p className="text-sm text-red-500 dark:text-red-400 p-2">{error}</p>}
                        <div ref={messagesEndRef} />
                    </>)}
                </div>
                {(mode !== 'Mentor' || activeLesson) &&
                <div className={`p-2 border-t border-blue-500/20 ${isLoading ? 'opacity-30 pointer-events-none' : ''}`}>
                    {mode === 'VedaQ' && <div className="mb-2"><h4 className="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1">Simulation Progress (Karma Score)</h4><SimulationKarmaChart data={karmaHistory} /></div>}
                    {showVoiceSettings && (<div className="p-2 mb-2 space-y-2 bg-gray-200/50 dark:bg-black/20 rounded-md"><select value={voiceSettings.voiceURI} onChange={e => setVoiceSettings(v => ({...v, voiceURI: e.target.value}))} className='w-full p-1.5 text-xs bg-gray-100 dark:bg-black/30 border border-blue-400/30 rounded-md focus:ring-1 focus:ring-blue-400 focus:outline-none transition'><option value="custom-voice-placeholder" disabled>Your Custom Voice (Requires Setup)</option>{availableVoices.map(voice => <option key={voice.voiceURI} value={voice.voiceURI}>{voice.name} ({voice.lang})</option>)}</select><button onClick={testVoice} className="w-full text-xs mt-1 px-3 py-1 bg-green-500/10 hover:bg-green-500/20 dark:bg-green-500/20 dark:hover:bg-green-500/40 border border-green-400/50 rounded-md transition-all text-green-700 dark:text-green-300">Test Voice</button><div className="text-xs text-gray-500 dark:text-gray-400 text-left mt-2 p-2 bg-gray-300/50 dark:bg-black/20 rounded-md"><strong className="block">To enable custom voice:</strong><ol className="list-decimal list-inside pl-1"><li>Choose a voice cloning provider (e.g., ElevenLabs).</li><li>Train your voice model on their platform.</li><li>Integrate their API to fetch and play the audio.</li></ol></div></div>)}
                    <form onSubmit={handleQuerySubmit} className="space-y-2">
                         {tutorial && tutorial.steps.length > 1 && (
                            <div className="flex justify-center items-center gap-4 bg-gray-200 dark:bg-black/20 p-2 rounded-md">
                                <button type="button" onClick={() => handleTutorialNavigation('back')} disabled={tutorial.currentStep === 0} className="px-4 py-1 text-sm rounded bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500 disabled:opacity-50">Back</button>
                                <span className="text-sm font-semibold">{`Step ${tutorial.currentStep + 1} of ${tutorial.steps.length}`}</span>
                                <button type="button" onClick={() => handleTutorialNavigation('next')} disabled={tutorial.currentStep === tutorial.steps.length - 1} className="px-4 py-1 text-sm rounded bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500 disabled:opacity-50">Next</button>
                            </div>
                        )}
                        <div className="flex items-center gap-2">
                           <textarea value={query} onChange={(e) => setQuery(e.target.value)} placeholder={mode === 'Mentor' ? "Answer your mentor..." : "Query the collective..."} rows={2} className="w-full p-2 bg-gray-100 dark:bg-black/30 border border-blue-400/30 rounded-md text-sm focus:ring-1 focus:ring-blue-400 focus:outline-none transition" disabled={isLoading}/>
                           <button type="button" onClick={handleImageGeneration} disabled={isLoading || !query.trim()} className="p-2 rounded-full transition-colors disabled:opacity-50 bg-purple-500/20 hover:bg-purple-500/40" title="Generate Image"><PaintBrushIcon className="w-5 h-5"/></button>
                           <button type="button" onClick={() => listening ? SpeechRecognition.stopListening() : SpeechRecognition.startListening()} disabled={!browserSupportsSpeechRecognition || isLoading} className={`p-2 rounded-full transition-colors disabled:opacity-50 ${listening ? 'bg-red-500/50' : 'bg-blue-500/20 hover:bg-blue-500/40'}`} title="Voice Input"><MicIcon className="w-5 h-5"/></button>
                        </div>
                        <button type="submit" disabled={isLoading || !query.trim()} className="w-full mt-2 text-center px-4 py-2 bg-blue-500/10 hover:bg-blue-500/20 dark:bg-blue-500/20 dark:hover:bg-blue-500/40 border border-blue-400/50 rounded-md transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-blue-700 dark:text-blue-300">{isLoading ? 'Thinking...' : 'Submit'}</button>
                    </form>
                    <button onClick={() => setShowVoiceSettings(!showVoiceSettings)} className="w-full text-xs text-center text-gray-500 dark:text-gray-400 mt-2 hover:underline">Toggle Voice Settings</button>
                </div>
                }
            </div>
        </div>
    );
};