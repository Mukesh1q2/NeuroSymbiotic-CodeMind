import React, { useEffect, useRef, useMemo } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Text, Line } from '@react-three/drei';
import type { DrawingCommand } from './VedicInsightGenerator';

// Helper to calculate the bounding box of points
const getBounds = (points: THREE.Vector3[]) => {
    const box = new THREE.Box3();
    points.forEach(p => box.expandByPoint(p));
    return box;
};

// A component to parse and render a function graph
const FunctionGraph: React.FC<{ command: Extract<DrawingCommand, { type: 'function_graph' }> }> = ({ command }) => {
    const points = useMemo(() => {
        const { equation, domain, steps = 100 } = command;
        const calculatedPoints: THREE.Vector3[] = [];
        try {
            const func = new Function('x', `with(Math){return ${equation}}`);
            const [start, end] = domain;
            const stepSize = (end - start) / steps;

            for (let i = 0; i <= steps; i++) {
                const x = start + i * stepSize;
                const y = func(x);
                if (Number.isFinite(y)) {
                    calculatedPoints.push(new THREE.Vector3(x, y, 0));
                }
            }
        } catch (e) {
            console.error("Error parsing function:", e);
            return [];
        }
        return calculatedPoints;
    }, [command]);

    if (points.length < 2) return null;

    return (
        <group>
            <Line
                points={points}
                color={command.color || '#FFFF00'}
                lineWidth={3}
            />
            {command.label && (
                 <Text
                    position={[points[Math.floor(points.length/2)].x, points[Math.floor(points.length/2)].y + 0.5, 0]}
                    fontSize={0.4}
                    color={command.color || '#FFFF00'}
                 >
                     {command.label}
                 </Text>
            )}
        </group>
    );
};

const AreaFill: React.FC<{ command: Extract<DrawingCommand, { type: 'area_fill' }> }> = ({ command }) => {
    const shape = useMemo(() => {
        const { equation, domain, steps = 100 } = command;
        const calculatedPoints: [number, number][] = [];
        try {
            const func = new Function('x', `with(Math){return ${equation}}`);
            const [start, end] = domain;
            const stepSize = (end - start) / steps;

            calculatedPoints.push([start, 0]);
            for (let i = 0; i <= steps; i++) {
                const x = start + i * stepSize;
                const y = func(x);
                if (Number.isFinite(y)) {
                    calculatedPoints.push([x, y]);
                }
            }
            calculatedPoints.push([end, 0]);
        } catch (e) {
            console.error("Error parsing function for area fill:", e);
            return null;
        }

        return new THREE.Shape(calculatedPoints.map(p => new THREE.Vector2(p[0], p[1])));
    }, [command]);
    
    if (!shape) return null;

    return (
        <mesh>
            <shapeGeometry args={[shape]} />
            <meshBasicMaterial color={command.color || '#00FF00'} transparent opacity={0.3} side={THREE.DoubleSide} />
        </mesh>
    );
};

const ShowcaseVisualization: React.FC = () => {
    const helixRef = useRef<THREE.Mesh>(null!);
    const points = useMemo(() => {
        const pts: THREE.Vector3[] = [];
        for (let t = -Math.PI * 4; t <= Math.PI * 4; t += 0.1) {
            pts.push(new THREE.Vector3(
                Math.cos(t) * 2,
                Math.sin(t) * 2,
                t * 0.5
            ));
        }
        return pts;
    }, []);

    useFrame(({ clock }) => {
        if (helixRef.current) {
            helixRef.current.rotation.z = clock.getElapsedTime() * 0.2;
        }
    });

    return (
        <group ref={helixRef}>
            <Line points={points} color="#FF7F50" lineWidth={4} />
            <Text position={[3, 0, 0]} fontSize={0.5} color="white" anchorX="left">
                3D Parametric Curves
            </Text>
             <Text position={[-3, 2, 4]} fontSize={0.5} color="cyan" anchorX="right">
                Live Rendering
            </Text>
             <Text position={[0, -2, -5]} fontSize={0.5} color="magenta">
                Interactive Canvas
            </Text>
        </group>
    );
};


const SceneContent: React.FC<{ drawingCommands: DrawingCommand[] }> = ({ drawingCommands }) => {
    const { camera, controls } = useThree();
    const gridRef = useRef<THREE.GridHelper>(null!);
    const axesRef = useRef<THREE.AxesHelper>(null!);

    useEffect(() => {
        if (!drawingCommands || drawingCommands.length === 0) {
            // Reset to default view
             if(controls) {
                (controls as any).target.set(0,0,0);
                (controls as any).object.position.set(8,8,8);
                (controls as any).update();
             }
             if(gridRef.current) gridRef.current.scale.set(1,1,1);
             if(axesRef.current) axesRef.current.scale.set(1,1,1);
            return;
        };

        const allPoints: THREE.Vector3[] = [];
        let isShowcase = false;
        drawingCommands.forEach(cmd => {
            if (cmd.type === 'showcase_visualization') {
                isShowcase = true;
            }
            if (cmd.type === 'line') {
                allPoints.push(new THREE.Vector3(...cmd.start), new THREE.Vector3(...cmd.end));
            } else if (cmd.type === 'function_graph') {
                 try {
                    const func = new Function('x', `with(Math){return ${cmd.equation}}`);
                    const [start, end] = cmd.domain;
                    const steps = cmd.steps || 100;
                    const stepSize = (end - start) / steps;
                    for (let i = 0; i <= steps; i++) {
                        const x = start + i * stepSize;
                        const y = func(x);
                        if(Number.isFinite(y)) allPoints.push(new THREE.Vector3(x, y, 0));
                    }
                 } catch(e) { /* ignore errors for bounds calculation */ }
            } else if (cmd.position) {
                 allPoints.push(new THREE.Vector3(...cmd.position));
            }
        });
        
        if (isShowcase) {
            if (controls) {
                (controls as any).target.set(0, 0, 0);
                (controls as any).object.position.set(0, 0, 10);
                (controls as any).update();
            }
            if(gridRef.current) gridRef.current.scale.set(1,1,1);
            if(axesRef.current) axesRef.current.scale.set(1,1,1);
        } else if (allPoints.length > 0 && controls) {
            const boundingBox = getBounds(allPoints);
            const center = boundingBox.getCenter(new THREE.Vector3());
            const size = boundingBox.getSize(new THREE.Vector3());
            
            const maxDim = Math.max(size.x, size.y, size.z);
            const fitOffset = 1.5;
            const distance = maxDim / (2 * Math.tan( (camera as THREE.PerspectiveCamera).fov * (Math.PI / 180) / 2 ));
            
            const newPos = new THREE.Vector3(center.x, center.y, center.z + distance * fitOffset);

            (controls as any).target.copy(center);
            (controls as any).object.position.copy(newPos);
            (controls as any).update();
            
            const gridSize = Math.max(10, Math.ceil(maxDim*1.2));
            if(gridRef.current) gridRef.current.scale.set(gridSize/20, gridSize/20, gridSize/20);
            if(axesRef.current) axesRef.current.scale.set(gridSize/20, gridSize/20, gridSize/20);
        }

    }, [drawingCommands, camera, controls]);

    return (
        <>
            <ambientLight intensity={0.6} />
            <pointLight position={[10, 10, 10]} intensity={1} />
            
            {/* Adaptive Coordinate System (Quadrant) */}
            <gridHelper ref={gridRef} args={[20, 20, '#444', '#888']} />
            <axesHelper ref={axesRef} args={[10]} />

            {/* Render dynamic commands */}
            {drawingCommands.map((cmd, index) => {
                const key = `${cmd.type}-${index}`;
                switch(cmd.type) {
                    case 'line':
                        return (
                            <Line
                                key={key}
                                points={[cmd.start, cmd.end]}
                                color={cmd.color || 'white'}
                                lineWidth={2}
                            />
                        );
                    case 'text':
                        return (
                             <Text
                                key={key}
                                position={cmd.position || [0, 0, 0]}
                                fontSize={cmd.size || 0.5}
                                color={cmd.color || 'white'}
                             >
                                 {cmd.text}
                             </Text>
                        );
                    case 'sphere':
                         return (
                            <mesh key={key} position={new THREE.Vector3(...(cmd.position || [0,0,0]))}>
                                <sphereGeometry args={[cmd.size || 0.2, 16, 16]} />
                                <meshStandardMaterial color={cmd.color || '#ff00ff'} roughness={0.5} metalness={0.5} />
                            </mesh>
                         );
                    case 'function_graph':
                        return <FunctionGraph key={key} command={cmd} />;
                    case 'area_fill':
                        return <AreaFill key={key} command={cmd} />;
                    case 'showcase_visualization':
                        return <ShowcaseVisualization key={key} />;
                    default:
                        return null;
                }
            })}

            <OrbitControls enableDamping dampingFactor={0.05} />
        </>
    );
};

export const VisualizationCanvas: React.FC<{ drawingCommands: DrawingCommand[] }> = ({ drawingCommands }) => {
    return (
        <Canvas camera={{ position: [8, 8, 8], fov: 60 }}>
            <color attach="background" args={['#1a202c']} />
            <SceneContent drawingCommands={drawingCommands} />
        </Canvas>
    );
};