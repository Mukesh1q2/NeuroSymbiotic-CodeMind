
import React, { useMemo } from 'react';
import type { AgentState } from '../../types';
import { BrainCircuitIcon, ChevronDownIcon, ChevronUpIcon } from './Icons';
import { GunaRadarChart } from './GunaRadarChart';

interface MetricDisplayProps {
  label: string;
  value: string;
  progress?: number;
}

const MetricDisplay: React.FC<MetricDisplayProps> = React.memo(({ label, value, progress }) => (
  <div className="text-sm">
    <div className="flex justify-between items-center mb-1">
      <span className="text-gray-600 dark:text-gray-300">{label}</span>
      <span className="font-bold text-amber-600 dark:text-amber-300">{value}</span>
    </div>
    {progress !== undefined && (
      <div className="w-full bg-gray-200 dark:bg-gray-700/50 rounded-full h-1.5">
        <div className="bg-gradient-to-r from-amber-500 to-yellow-400 dark:from-amber-500 dark:to-yellow-300 h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
      </div>
    )}
  </div>
));

interface EvolutionDashboardProps {
  agents: AgentState[];
  time: number;
  isMinimized: boolean;
  toggleMinimize: () => void;
  darkMode: boolean;
}

export const EvolutionDashboard: React.FC<EvolutionDashboardProps> = ({ agents, isMinimized, toggleMinimize, darkMode }) => {
  const metrics = useMemo(() => {
    if (agents.length === 0) {
      return { api: 0, karmaScore: 100, gunaBalance: { sattva: 0, rajas: 0, tamas: 0 }, cq: 0, mokshaReadiness: 0, agentCount: 0 };
    }
    const totalAwareness = agents.reduce((sum, a) => sum + a.quantum.awareness, 0) / agents.length;
    const averageCoherence = agents.reduce((sum, a) => sum + a.quantum.coherence, 0) / agents.length;
    const totalKarmicBurden = agents.reduce((sum, a) => sum + a.karmicBurden, 0) / agents.length;
    const mokshaReadyCount = agents.filter(a => a.consciousness > 0.9 && a.karmicBurden < 0.1).length;
    const totalGunas = agents.reduce((acc, a) => { acc.sattva += a.gunas.sattva; acc.rajas += a.gunas.rajas; acc.tamas += a.gunas.tamas; return acc; }, { sattva: 0, rajas: 0, tamas: 0 });
    const entanglementLinks = agents.reduce((sum, a) => sum + Object.keys(a.quantum.entanglement).length, 0);
    const possibleLinks = agents.length * (agents.length - 1);
    const interactionDensity = possibleLinks > 0 ? entanglementLinks / possibleLinks : 0;
    const api = totalAwareness * averageCoherence;
    const karmaScore = Math.max(0, 100 - totalKarmicBurden * 50);
    const gunaBalance = { sattva: totalGunas.sattva / agents.length, rajas: totalGunas.rajas / agents.length, tamas: totalGunas.tamas / agents.length };
    const cq = api * 0.7 + interactionDensity * 0.3;
    const mokshaReadiness = (mokshaReadyCount / agents.length) * 100;
    return { api, karmaScore, gunaBalance, cq, mokshaReadiness, agentCount: agents.length };
  }, [agents]);

  return (
    <div className="bg-white/60 dark:bg-black/40 backdrop-blur-sm border border-amber-500/20 rounded-lg shadow-lg dark:shadow-amber-500/5">
      <div className="p-3 border-b border-amber-500/20 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <BrainCircuitIcon className="w-5 h-5 text-amber-500 dark:text-amber-400" />
          <h3 className="font-bold text-md text-gray-800 dark:text-white">VedaQ Dashboard</h3>
        </div>
        <button onClick={toggleMinimize} className="text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white">
          {isMinimized ? <ChevronDownIcon className="w-5 h-5" /> : <ChevronUpIcon className="w-5 h-5" />}
        </button>
      </div>
      <div className={`transition-all duration-500 ease-in-out overflow-hidden ${isMinimized ? 'max-h-0 opacity-0' : 'max-h-screen opacity-100'}`}>
        <div className="p-4 space-y-4">
            <GunaRadarChart gunas={metrics.gunaBalance} darkMode={darkMode} />
            <MetricDisplay label="Agent Count" value={String(metrics.agentCount)} />
            <MetricDisplay label="APIx" value={metrics.api.toFixed(3)} progress={metrics.api * 100} />
            <MetricDisplay label="Karma Score" value={metrics.karmaScore.toFixed(1)} progress={metrics.karmaScore} />
            <MetricDisplay label="Consciousness Quotient" value={metrics.cq.toFixed(3)} progress={metrics.cq * 100} />
            <MetricDisplay label="Moksha Readiness" value={`${metrics.mokshaReadiness.toFixed(1)}%`} progress={metrics.mokshaReadiness} />
        </div>
      </div>
    </div>
  );
};