
import React from 'react';
import type { CollapseEvent } from '../../types';
import { ZapIcon, ChevronDownIcon, ChevronUpIcon } from './Icons';

interface CollapseEventLogProps {
  events: CollapseEvent[];
  isMinimized: boolean;
  toggleMinimize: () => void;
}

const LogEntry: React.FC<{ event: CollapseEvent }> = React.memo(({ event }) => (
    <div className="p-2 border-l-2 border-yellow-400/30 bg-yellow-400/10 rounded-r-md animate-pulse-once">
      <div className="flex justify-between items-center text-xs">
        <span className="font-bold text-yellow-600 dark:text-yellow-300">Agent {event.agentId}</span>
        <span className="text-gray-500 dark:text-gray-400">T: {event.timestamp}</span>
      </div>
      <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">
        Intensity: {event.intensity.toFixed(3)} at ({event.position.x.toFixed(1)}, {event.position.y.toFixed(1)}, {event.position.z.toFixed(1)})
      </p>
    </div>
));

export const CollapseEventLog: React.FC<CollapseEventLogProps> = ({ events, isMinimized, toggleMinimize }) => {
  const reversedEvents = React.useMemo(() => [...events].reverse(), [events]);

  return (
    <div className="bg-white/60 dark:bg-black/40 backdrop-blur-sm border border-yellow-500/20 rounded-lg flex flex-col shadow-lg dark:shadow-yellow-500/5">
      <div className="p-3 border-b border-yellow-500/20 flex items-center justify-between">
        <div className="flex items-center space-x-3">
            <ZapIcon className="w-5 h-5 text-yellow-500 dark:text-yellow-400" />
            <h3 className="font-bold text-md text-gray-800 dark:text-white">Collapse Event Log</h3>
        </div>
         <button onClick={toggleMinimize} className="text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white">
          {isMinimized ? <ChevronDownIcon className="w-5 h-5" /> : <ChevronUpIcon className="w-5 h-5" />}
        </button>
      </div>
       <div className={`transition-all duration-500 ease-in-out overflow-hidden flex-grow flex flex-col ${isMinimized ? 'max-h-0 opacity-0' : 'max-h-screen opacity-100'}`}>
        <div className="p-2 space-y-2 overflow-y-auto flex-grow">
            {reversedEvents.length === 0 ? (
            <div className="text-center text-gray-500 dark:text-gray-400 text-sm p-4">Awaiting collapse events...</div>
            ) : (
            reversedEvents.map((event, index) => <LogEntry key={`${event.timestamp}-${event.agentId}-${index}`} event={event} />)
            )}
        </div>
      </div>
    </div>
  );
};