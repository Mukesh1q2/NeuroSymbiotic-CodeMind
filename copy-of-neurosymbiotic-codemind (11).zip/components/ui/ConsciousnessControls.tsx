import React from 'react';
import type { SimulationParams, FieldShape } from '../../types';
import { SettingsIcon, ChevronDownIcon, ChevronUpIcon, CubeIcon, SphereIcon, TorusIcon } from './Icons';

interface ControlSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
  displayValue?: string;
}

const ControlSlider: React.FC<ControlSliderProps> = React.memo(({ label, value, min, max, step, onChange, displayValue }) => (
  <div className="text-sm">
    <label className="flex justify-between items-center text-gray-600 dark:text-gray-300 mb-1">
      <span>{label}</span>
      <span className="font-bold text-cyan-600 dark:text-cyan-300">{displayValue || value.toFixed(3)}</span>
    </label>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="w-full h-2 bg-gray-200 dark:bg-gray-700/50 rounded-lg appearance-none cursor-pointer accent-cyan-500 dark:accent-cyan-400"
    />
  </div>
));

interface ConsciousnessControlsProps {
  params: SimulationParams;
  setParams: React.Dispatch<React.SetStateAction<SimulationParams>>;
  onReset: () => void;
  togglePause: () => void;
  isPaused: boolean;
  isMinimized: boolean;
  toggleMinimize: () => void;
  fieldShape: FieldShape;
  onShapeChange: (shape: FieldShape) => void;
  volume: number;
  onVolumeChange: (volume: number) => void;
}

export const ConsciousnessControls: React.FC<ConsciousnessControlsProps> = ({
  params,
  setParams,
  onReset,
  togglePause,
  isPaused,
  isMinimized,
  toggleMinimize,
  fieldShape,
  onShapeChange,
  volume,
  onVolumeChange,
}) => {
  const handleParamChange = (key: keyof SimulationParams, value: number) => {
    setParams(p => ({ ...p, [key]: value }));
  };

  const shapeControls: { shape: FieldShape; icon: React.ReactNode }[] = [
    { shape: 'cube', icon: <CubeIcon className="w-5 h-5" /> },
    { shape: 'sphere', icon: <SphereIcon className="w-5 h-5" /> },
    { shape: 'torus', icon: <TorusIcon className="w-5 h-5" /> },
  ];

  return (
    <div className="bg-white/60 dark:bg-black/40 backdrop-blur-sm border border-cyan-500/20 rounded-lg shadow-lg dark:shadow-cyan-500/5">
      <div className="p-3 border-b border-cyan-500/20 flex items-center justify-between">
        <div className="flex items-center space-x-3">
            <SettingsIcon className="w-5 h-5 text-cyan-500 dark:text-cyan-400" />
            <h3 className="font-bold text-md text-gray-800 dark:text-white">Consciousness Controls</h3>
        </div>
        <button onClick={toggleMinimize} className="text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white">
           {isMinimized ? <ChevronDownIcon className="w-5 h-5" /> : <ChevronUpIcon className="w-5 h-5" />}
        </button>
      </div>
      <div className={`transition-all duration-500 ease-in-out overflow-hidden ${isMinimized ? 'max-h-0 opacity-0' : 'max-h-screen opacity-100'}`}>
          <div className="p-4 space-y-4">
             <ControlSlider 
              label="Master Volume" 
              value={volume} 
              min={0} max={1} step={0.05} 
              onChange={onVolumeChange}
              displayValue={`${Math.round(volume * 100)}%`}
            />
            <ControlSlider 
              label="Agent Count" 
              value={params.agentCount} 
              min={1} max={200} step={1} 
              onChange={(v) => handleParamChange('agentCount', v)}
              displayValue={String(params.agentCount)}
            />
            <ControlSlider 
              label="Decoherence Rate" 
              value={params.decoherenceRate} 
              min={0} max={0.2} step={0.001} 
              onChange={(v) => handleParamChange('decoherenceRate', v)} 
            />
            <ControlSlider 
              label="Interaction Range" 
              value={params.interactionRange} 
              min={1} max={30} step={0.5} 
              onChange={(v) => handleParamChange('interactionRange', v)} 
            />
            <ControlSlider 
              label="Collapse Threshold" 
              value={params.collapseThreshold} 
              min={0.01} max={0.99} step={0.01} 
              onChange={(v) => handleParamChange('collapseThreshold', v)} 
            />
             <ControlSlider 
              label="Quantum Diffusion" 
              value={params.quantumDiffusion} 
              min={0} max={0.5} step={0.01} 
              onChange={(v) => handleParamChange('quantumDiffusion', v)} 
            />
            <ControlSlider 
              label="Sankalpa Strength" 
              value={params.sankalpaStrength} 
              min={0} max={0.5} step={0.01} 
              onChange={(v) => handleParamChange('sankalpaStrength', v)} 
            />
          </div>
          <div className="p-4 border-t border-cyan-500/20 space-y-3">
            <div>
                <label className="block text-sm text-gray-600 dark:text-gray-300 mb-2">Field Shape</label>
                <div className="flex justify-around bg-gray-200 dark:bg-black/30 p-1 rounded-md">
                    {shapeControls.map(({ shape, icon }) => (
                        <button
                            key={shape}
                            onClick={() => onShapeChange(shape)}
                            className={`p-2 rounded transition-colors ${fieldShape === shape ? 'bg-cyan-500/80 text-white' : 'hover:bg-cyan-500/20 text-gray-600 dark:text-gray-300'}`}
                            title={shape.charAt(0).toUpperCase() + shape.slice(1)}
                        >
                            {icon}
                        </button>
                    ))}
                </div>
            </div>
            <div className="flex justify-between space-x-2">
                <button
                  onClick={togglePause}
                  className="w-full text-center px-4 py-2 bg-blue-500/10 hover:bg-blue-500/20 dark:bg-blue-500/20 dark:hover:bg-blue-500/40 border border-blue-400/50 rounded-md transition-all duration-200 text-blue-700 dark:text-blue-300"
                >
                  {isPaused ? 'Resume' : 'Pause'}
                </button>
                <button
                  onClick={onReset}
                  className="w-full text-center px-4 py-2 bg-red-500/10 hover:bg-red-500/20 dark:bg-red-500/20 dark:hover:bg-red-500/40 border border-red-400/50 rounded-md transition-all duration-200 text-red-700 dark:text-red-300"
                >
                  Reset
                </button>
            </div>
          </div>
      </div>
    </div>
  );
};