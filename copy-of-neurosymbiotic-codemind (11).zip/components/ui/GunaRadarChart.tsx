
import React from 'react';

interface GunaRadarChartProps {
  gunas: {
    sattva: number;
    rajas: number;
    tamas: number;
  };
  size?: number;
  darkMode?: boolean;
}

export const GunaRadarChart: React.FC<GunaRadarChartProps> = ({ gunas, size = 140, darkMode = true }) => {
  const center = size / 2;
  const radius = size * 0.35;

  const points = [
    { label: 'Sattva', value: gunas.sattva, angle: -Math.PI / 2 },
    { label: 'Rajas', value: gunas.rajas, angle: (Math.PI * 7) / 6 },
    { label: 'Tamas', value: gunas.tamas, angle: -Math.PI / 6 },
  ];

  const getCoords = (value: number, angle: number) => {
    const x = center + radius * value * Math.cos(angle);
    const y = center + radius * value * Math.sin(angle);
    return `${x},${y}`;
  };

  const dataPath = points.map(p => getCoords(p.value, p.angle)).join(' ');
  
  const gradientId = `gunaGradient-${darkMode}`;
  const strokeColor = darkMode ? "#FBBF24" : "#D97706";
  const labelColor = darkMode ? "#d1d5db" : "#374151";
  const gridColor = darkMode ? "rgba(107, 114, 128, 0.3)" : "rgba(156, 163, 175, 0.5)";

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
            <linearGradient id={gradientId} x1="50%" y1="0%" x2="50%" y2="100%">
                <stop offset="0%" stopColor={strokeColor} stopOpacity="0.6" />
                <stop offset="100%" stopColor={darkMode ? "#60a5fa" : "#3B82F6"} stopOpacity="0.6" />
            </linearGradient>
        </defs>
        
        {/* Background Grid */}
        <g stroke={gridColor} strokeWidth="0.5">
          {[0.25, 0.5, 0.75, 1].map(r => (
            <polygon
              key={r}
              points={points.map(p => getCoords(r, p.angle)).join(' ')}
              fill="none"
              strokeDasharray="2,2"
            />
          ))}
          {points.map(p => (
            <line key={p.label} x1={center} y1={center} x2={getCoords(1, p.angle).split(',')[0]} y2={getCoords(1, p.angle).split(',')[1]} />
          ))}
        </g>

        {/* Data Polygon */}
        <polygon points={dataPath} fill={`url(#${gradientId})`} stroke={strokeColor} strokeWidth="1.5" />

        {/* Labels */}
        {points.map(p => {
          const [x, y] = getCoords(1.3, p.angle).split(',').map(parseFloat);
          return (
            <text
              key={p.label}
              x={x}
              y={y}
              fill={labelColor}
              fontSize="11"
              fontWeight="bold"
              textAnchor="middle"
              dominantBaseline="middle"
            >
              {p.label}
            </text>
          );
        })}
      </svg>
    </div>
  );
};