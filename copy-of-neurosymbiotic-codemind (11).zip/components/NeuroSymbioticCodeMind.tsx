
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import type { AgentState, CollapseEvent, SimulationParams, FieldShape } from '../types';
import { SimulationEngine } from '../services/simulationEngine';
import { INITIAL_SIMULATION_PARAMS, DREAMLIKE_PARAMS_PARTIAL } from '../constants';
import { AgentManager } from './visualization/AgentManager';
import { QuantumField } from './visualization/QuantumField';
import { EvolutionDashboard } from './ui/EvolutionDashboard';
import { ConsciousnessControls } from './ui/ConsciousnessControls';
import { CollapseEventLog } from './ui/CollapseEventLog';
import { Chatbox, DrawingCommand, TutorialStep } from './ui/VedicInsightGenerator';
import { VisualizationCanvas } from './ui/VisualizationCanvas';
import { EyeIcon, EyeOffIcon, SunIcon, MoonIcon, BrainCircuitIcon, BookOpenIcon, LayoutGridIcon } from './ui/Icons';

interface NeuroSymbioticCodeMindProps {
    darkMode: boolean;
    toggleDarkMode: () => void;
}

type MainView = 'simulation' | 'mentorCanvas';

export const NeuroSymbioticCodeMind: React.FC<NeuroSymbioticCodeMindProps> = ({ darkMode, toggleDarkMode }) => {
  const [params, setParams] = useState<SimulationParams>(INITIAL_SIMULATION_PARAMS);
  const [uiAgents, setUiAgents] = useState<AgentState[]>([]);
  const [collapseEvents, setCollapseEvents] = useState<CollapseEvent[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  const [time, setTime] = useState(0);
  const [isDreamMode, setIsDreamMode] = useState(false);
  const [karmaHistory, setKarmaHistory] = useState<number[]>([]);
  const [fieldShape, setFieldShape] = useState<FieldShape>('cube');
  const [volume, setVolume] = useState(0.5);
  const [mainView, setMainView] = useState<MainView>('simulation');
  const [isSplitView, setIsSplitView] = useState(false);
  const [tutorial, setTutorial] = useState<{ steps: TutorialStep[]; currentStep: number } | null>(null);

  const agentsRef = useRef<AgentState[]>([]);
  const simulationEngineRef = useRef<SimulationEngine>(new SimulationEngine());
  const animationFrameIdRef = useRef<number | null>(null);
  const normalParamsRef = useRef<SimulationParams>(INITIAL_SIMULATION_PARAMS);
  
  const [panelVisibility, setPanelVisibility] = useState({
    dashboard: true,
    controls: true,
    log: true,
    chat: true,
  });

  const [panelState, setPanelState] = useState({
    dashboard: { minimized: false },
    controls: { minimized: false },
    log: { minimized: false },
    chat: { minimized: false },
  });
  
  const togglePanel = (panel: keyof typeof panelVisibility) => {
    setPanelVisibility(prev => ({ ...prev, [panel]: !prev[panel] }));
  };

  const toggleMinimize = (panel: keyof typeof panelState) => {
    setPanelState(prev => ({ ...prev, [panel]: { minimized: !prev[panel].minimized } }));
  };

  const handleShapeChange = (shape: FieldShape) => {
    setFieldShape(shape);
  };

  const handleTutorialChange = useCallback((newTutorial: { steps: TutorialStep[]; currentStep: number } | null) => {
      setTutorial(newTutorial);
      if(newTutorial && newTutorial.steps.length > 0 && !isSplitView) {
        setMainView('mentorCanvas');
      }
  }, [isSplitView]);

  const resetSimulation = useCallback((p: SimulationParams) => {
    simulationEngineRef.current = new SimulationEngine();
    const newAgents = Array.from({ length: p.agentCount }, (_, i) => simulationEngineRef.current.createAgent(i, p));
    agentsRef.current = newAgents;
    setUiAgents(newAgents);
    setCollapseEvents([]);
    setKarmaHistory([]);
    setTime(0);
  }, []);

  useEffect(() => {
    resetSimulation(params);
  }, [params.agentCount, resetSimulation]);
  
  // High-frequency simulation loop (60fps)
  const simulationLoop = useCallback(() => {
    if (!isPaused) {
      const { updatedAgents, newCollapseEvents } = simulationEngineRef.current.step(agentsRef.current, params);
      agentsRef.current = updatedAgents;
      if (newCollapseEvents.length > 0) {
        setCollapseEvents(prevEvents => [...prevEvents, ...newCollapseEvents].slice(-100));
      }
    }
    animationFrameIdRef.current = requestAnimationFrame(simulationLoop);
  }, [isPaused, params]);
  
  // Low-frequency UI update loop (e.g., 4fps)
  const uiUpdateLoop = useCallback(() => {
    if (!isPaused) {
      setUiAgents([...agentsRef.current]);
      setTime(t => t + 1);
    }
  }, [isPaused]);


  useEffect(() => {
    animationFrameIdRef.current = requestAnimationFrame(simulationLoop);
    const uiInterval = setInterval(uiUpdateLoop, 250); // Update UI 4 times per second

    return () => {
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
      clearInterval(uiInterval);
    };
  }, [simulationLoop, uiUpdateLoop]);

  const togglePause = () => setIsPaused(p => !p);

  const handleDreamStateChange = useCallback((isDreaming: boolean) => {
    setIsDreamMode(isDreaming);
    if (isDreaming) {
        setParams(currentParams => {
            normalParamsRef.current = currentParams; // Save current params
            return { ...currentParams, ...DREAMLIKE_PARAMS_PARTIAL };
        });
    } else {
        setParams(normalParamsRef.current); // Restore saved params
    }
  }, []);

  const metrics = useMemo(() => {
    if (uiAgents.length === 0) return { karmaScore: 100 };
    const totalKarmicBurden = uiAgents.reduce((sum, a) => sum + a.karmicBurden, 0) / uiAgents.length;
    return { karmaScore: Math.max(0, 100 - totalKarmicBurden * 50) };
  }, [uiAgents]);

  useEffect(() => {
    if (!isPaused && time % 2 === 0) { // Update roughly every 2 * 250ms = 0.5s
        setKarmaHistory(prev => [...prev.slice(-99), metrics.karmaScore]);
    }
  }, [time, isPaused, metrics.karmaScore]);
  
  const currentDrawingCommands = tutorial?.steps[tutorial.currentStep]?.drawingCommands || [];

    const renderSimulationView = () => (
        <div className="w-full h-full rounded-lg overflow-hidden border border-white/10 shadow-2xl bg-black">
            <Canvas camera={{ position: [0, 20, 50], fov: 60 }}>
                <ambientLight intensity={darkMode ? 0.2 : 0.6} />
                <pointLight position={[0, 30, 0]} intensity={darkMode ? 1.5 : 2} color="#FBBF24" />
                <pointLight position={[30, 0, 30]} intensity={darkMode ? 1 : 1.5} color="#2dd4bf" />
                <pointLight position={[-30, 0, -30]} intensity={darkMode ? 1 : 1.5} color="#60a5fa" />
                <QuantumField agents={agentsRef.current} collapseEvents={collapseEvents} shape={fieldShape} dreamMode={isDreamMode} />
                <AgentManager agents={agentsRef.current} collapseEvents={collapseEvents} volume={volume} />
                <Stars radius={200} depth={50} count={5000} factor={4} saturation={1} fade speed={1} />
                <OrbitControls enableDamping dampingFactor={0.05} />
            </Canvas>
        </div>
    );
    
    const renderMentorCanvasView = () => (
        <div className="w-full h-full rounded-lg overflow-hidden border border-white/10 shadow-2xl bg-black">
           <VisualizationCanvas drawingCommands={currentDrawingCommands} />
        </div>
    );

  return (
    <div className="w-full h-full flex flex-col">
        {/* Header */}
        <header className="p-3 flex justify-between items-center border-b border-white/10 bg-gray-100/5 dark:bg-black/20">
            <div className="text-center">
                <h1 className="text-xl font-bold tracking-wider text-gray-800 dark:text-white/90">NSCM VedaQ</h1>
                <p className="text-xs text-gray-600 dark:text-gray-400">An Interactive Model of Emergent Consciousness</p>
            </div>
            <div className="flex items-center gap-2">
                 <div className="flex items-center gap-1 bg-gray-200 dark:bg-black/30 p-1 rounded-md">
                     <button
                        onClick={() => setMainView('simulation')}
                        className={`p-2 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${mainView === 'simulation' && !isSplitView ? 'bg-blue-500/80 text-white' : 'hover:bg-blue-500/20 text-gray-600 dark:text-gray-300'}`}
                        title="Simulation View"
                        disabled={isSplitView}
                     >
                        <BrainCircuitIcon className="w-5 h-5"/>
                     </button>
                      <button
                        onClick={() => setMainView('mentorCanvas')}
                        className={`p-2 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${mainView === 'mentorCanvas' && !isSplitView ? 'bg-amber-500/80 text-white' : 'hover:bg-amber-500/20 text-gray-600 dark:text-gray-300'}`}
                        title="Mentor Canvas"
                        disabled={isSplitView}
                     >
                        <BookOpenIcon className="w-5 h-5"/>
                     </button>
                 </div>
                 <div className="w-px h-6 bg-gray-500/50 mx-1"></div>
                 <button
                    onClick={() => setIsSplitView(!isSplitView)}
                    className={`p-2 rounded transition-colors ${isSplitView ? 'bg-indigo-500/80 text-white' : 'bg-gray-500/20 hover:bg-indigo-500/20'}`}
                    title="Split View"
                 >
                    <LayoutGridIcon className="w-5 h-5"/>
                 </button>
                 <div className="w-px h-6 bg-gray-500/50 mx-1"></div>
                 <button onClick={toggleDarkMode} className="p-2 rounded-full bg-gray-500/20 backdrop-blur-sm" title="Toggle Theme">
                    {darkMode ? <SunIcon className="w-5 h-5 text-yellow-300"/> : <MoonIcon className="w-5 h-5 text-indigo-300"/>}
                 </button>
            </div>
        </header>

       <div className="flex-grow p-4 grid grid-cols-1 lg:grid-cols-12 grid-rows-1 lg:grid-rows-1 gap-4 overflow-hidden relative">
            {/* Left Panels */}
            <div className="hidden lg:flex lg:col-span-3 lg:row-span-1 flex-col gap-4 overflow-y-auto pr-2">
                {panelVisibility.dashboard && <EvolutionDashboard agents={uiAgents} time={time} isMinimized={panelState.dashboard.minimized} toggleMinimize={() => toggleMinimize('dashboard')} darkMode={darkMode} />}
                {panelVisibility.controls && <ConsciousnessControls 
                params={params} 
                setParams={setParams} 
                onReset={() => resetSimulation(params)} 
                togglePause={togglePause} 
                isPaused={isPaused}
                isMinimized={panelState.controls.minimized} 
                toggleMinimize={() => toggleMinimize('controls')}
                fieldShape={fieldShape}
                onShapeChange={handleShapeChange}
                volume={volume}
                onVolumeChange={setVolume}
                />}
            </div>
            
            {/* Center Canvas */}
            <div className="col-span-1 lg:col-span-6 row-span-1 h-full min-h-0">
               {isSplitView ? (
                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
                    {renderSimulationView()}
                    {renderMentorCanvasView()}
                 </div>
               ) : (
                    mainView === 'simulation' ? renderSimulationView() : renderMentorCanvasView()
               )}
            </div>

            {/* Right Panels */}
            <div className="hidden lg:flex lg:col-span-3 lg:row-span-1 flex-col gap-4 overflow-y-auto pr-2">
                {panelVisibility.log && <CollapseEventLog events={collapseEvents} isMinimized={panelState.log.minimized} toggleMinimize={() => toggleMinimize('log')} />}
                {panelVisibility.chat && <Chatbox agents={uiAgents} karmaHistory={karmaHistory} isMinimized={panelState.chat.minimized} toggleMinimize={() => toggleMinimize('chat')} onDreamStateChange={handleDreamStateChange} onTutorialChange={handleTutorialChange} tutorial={tutorial} />}
            </div>

        {/* Panel Visibility Toggles */}
        <div className="absolute bottom-4 left-4 z-10 hidden lg:flex flex-wrap gap-2 items-center">
            <button onClick={() => togglePanel('dashboard')} className={`p-2 rounded-full transition-colors ${panelVisibility.dashboard ? 'bg-amber-500/80' : 'bg-gray-500/80'} backdrop-blur-sm`} title="Toggle Dashboard">{panelVisibility.dashboard ? <EyeOffIcon className="w-5 h-5"/> : <EyeIcon className="w-5 h-5"/>}</button>
            <button onClick={() => togglePanel('controls')} className={`p-2 rounded-full transition-colors ${panelVisibility.controls ? 'bg-cyan-500/80' : 'bg-gray-500/80'} backdrop-blur-sm`} title="Toggle Controls">{panelVisibility.controls ? <EyeOffIcon className="w-5 h-5"/> : <EyeIcon className="w-5 h-5"/>}</button>
            <button onClick={() => togglePanel('log')} className={`p-2 rounded-full transition-colors ${panelVisibility.log ? 'bg-yellow-500/80' : 'bg-gray-500/80'} backdrop-blur-sm`} title="Toggle Log">{panelVisibility.log ? <EyeOffIcon className="w-5 h-5"/> : <EyeIcon className="w-5 h-5"/>}</button>
            <button onClick={() => togglePanel('chat')} className={`p-2 rounded-full transition-colors ${panelVisibility.chat ? 'bg-blue-500/80' : 'bg-gray-500/80'} backdrop-blur-sm`} title="Toggle Chatbox">{panelVisibility.chat ? <EyeOffIcon className="w-5 h-5"/> : <EyeIcon className="w-5 h-5"/>}</button>
        </div>
        
        {/* Mobile Panel Container */}
        <div className="lg:hidden absolute top-0 left-0 w-full h-full p-4 overflow-y-auto pointer-events-none mt-[70px]">
            <div className="flex flex-col gap-4 pointer-events-auto">
                {panelVisibility.dashboard && <EvolutionDashboard agents={uiAgents} time={time} isMinimized={panelState.dashboard.minimized} toggleMinimize={() => toggleMinimize('dashboard')} darkMode={darkMode} />}
                {panelVisibility.controls && <ConsciousnessControls 
                    params={params} setParams={setParams} onReset={() => resetSimulation(params)} 
                    togglePause={togglePause} isPaused={isPaused} isMinimized={panelState.controls.minimized} toggleMinimize={() => toggleMinimize('controls')}
                    fieldShape={fieldShape} onShapeChange={handleShapeChange}
                    volume={volume}
                    onVolumeChange={setVolume}
                />}
                {panelVisibility.log && <CollapseEventLog events={collapseEvents} isMinimized={panelState.log.minimized} toggleMinimize={() => toggleMinimize('log')} />}
                {panelVisibility.chat && <Chatbox agents={uiAgents} karmaHistory={karmaHistory} isMinimized={panelState.chat.minimized} toggleMinimize={() => toggleMinimize('chat')} onDreamStateChange={handleDreamStateChange} onTutorialChange={handleTutorialChange} tutorial={tutorial} />}
            </div>
        </div>
      </div>
    </div>
  );
};
