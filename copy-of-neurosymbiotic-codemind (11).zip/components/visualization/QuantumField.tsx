import React, { useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import type { AgentState, CollapseEvent, FieldShape } from '../../types';
import { FIELD_GRID_SIZE, FIELD_SIZE } from '../../constants';

interface QuantumFieldProps {
  agents: AgentState[];
  collapseEvents: CollapseEvent[];
  shape: FieldShape;
  dreamMode: boolean;
}

const particleGeometry = new THREE.SphereGeometry(0.1, 8, 8);
const particleMaterial = new THREE.MeshStandardMaterial({
    roughness: 0.5,
    metalness: 0.5,
    vertexColors: true,
});
const dummy = new THREE.Object3D();

export const QuantumField: React.FC<QuantumFieldProps> = ({ agents, collapseEvents, shape, dreamMode }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null!);
  const timeRef = useRef(0);
  const { camera } = useThree();

  const { positions, baseColors } = useMemo(() => {
    const gridSize = FIELD_GRID_SIZE;
    const count = gridSize * gridSize * gridSize;
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
        const x = i % gridSize;
        const y = Math.floor(i / gridSize) % gridSize;
        const z = Math.floor(i / (gridSize * gridSize));

        let xPos, yPos, zPos;

        if (shape === 'sphere') {
            const r = FIELD_SIZE * 0.9;
            const phi = Math.acos(1 - 2 * (i / (count-1) ));
            const theta = Math.sqrt(count * Math.PI) * phi;
            xPos = r * Math.cos(theta) * Math.sin(phi);
            yPos = r * Math.sin(theta) * Math.sin(phi);
            zPos = r * Math.cos(phi);
        } else if (shape === 'torus') {
            const R = FIELD_SIZE * 0.7; // Major radius
            const r = FIELD_SIZE * 0.3; // Minor radius
            const u = (x / gridSize) * Math.PI * 2;
            const v = (y / gridSize) * Math.PI * 2 + (z/(gridSize-1)) * Math.PI*2; // Use z to sample around minor radius
            xPos = (R + r * Math.cos(v)) * Math.cos(u);
            yPos = (R + r * Math.cos(v)) * Math.sin(u);
            zPos = r * Math.sin(v);
        } else { // cube
            const spacing = FIELD_SIZE * 2 / gridSize;
            const halfGrid = (gridSize * spacing) / 2;
            xPos = x * spacing - halfGrid;
            yPos = y * spacing - halfGrid;
            zPos = z * spacing - halfGrid;
        }

        pos[i * 3] = xPos;
        pos[i * 3 + 1] = yPos;
        pos[i * 3 + 2] = zPos;
    
        const c = new THREE.Color();
        c.setHSL(0.6 + Math.random()*0.2, 0.7, 0.1);
        col[i * 3] = c.r;
        col[i * 3 + 1] = c.g;
        col[i * 3 + 2] = c.b;
    }
    return { positions: pos, baseColors: col };
  }, [shape]);
  
  const tempVec = useMemo(() => new THREE.Vector3(), []);
  const tempColor = useMemo(() => new THREE.Color(), []);

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    timeRef.current = clock.getElapsedTime();

    const interactionRangeSq = 15 * 15;
    const dynamicThresholds = [FIELD_SIZE * 0.4, FIELD_SIZE * 0.8, FIELD_SIZE * 1.2];

    for (let i = 0; i < positions.length / 3; i++) {
        const i3 = i * 3;
        tempVec.set(positions[i3], positions[i3+1], positions[i3+2]);

        const distToCam = tempVec.distanceTo(camera.position);
        let lodLevel = 3; // Minimal (hide)
        if (distToCam < dynamicThresholds[0]) lodLevel = 0; // High detail
        else if (distToCam < dynamicThresholds[1]) lodLevel = 1; // Medium
        else if (distToCam < dynamicThresholds[2]) lodLevel = 2; // Low
        
        if (lodLevel === 3) {
            dummy.scale.set(0, 0, 0);
        } else {
            dummy.scale.set(1, 1, 1);
        }

        dummy.position.copy(tempVec);
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);

        if (dreamMode) {
            const swirlSpeed = 0.2;
            const colorPhase = (clock.getElapsedTime() * swirlSpeed + i * 0.001) % 1;
            tempColor.setHSL(colorPhase, 0.8, 0.6);
        } else {
            let fieldIntensity = 0;
            let quantumPotential = 0;
            let totalSuperposition = 0;
            let totalPhase = 0;
            let agentCount = 0;

            agents.forEach(agent => {
                const distSq = tempVec.distanceToSquared(agent.vibrational.position);
                if (distSq < interactionRangeSq) {
                    const influence = Math.exp(-distSq / 50) * agent.consciousness;
                    fieldIntensity += influence;
                    quantumPotential += agent.quantum.awareness * influence;
                    totalSuperposition += agent.quantum.superposition * influence;
                    totalPhase += agent.quantum.phase * influence;
                    agentCount++;
                }
            });

            if (agentCount > 0) {
                totalSuperposition /= agentCount;
                totalPhase /= agentCount;
            }

            collapseEvents.forEach(event => {
                if (timeRef.current - event.timestamp / 60 < 2) {
                    const dist = tempVec.distanceTo(event.position);
                    const rippleTime = timeRef.current - event.timestamp / 60;
                    const rippleDist = rippleTime * 20;
                    const ripple = Math.sin(dist - rippleDist) * Math.exp(-rippleTime) * event.intensity;
                    fieldIntensity += Math.abs(ripple) * 0.2;
                }
            });
            
            tempColor.setRGB(baseColors[i3], baseColors[i3+1], baseColors[i3+2]);
            tempColor.lerp(new THREE.Color(0x88ddff), fieldIntensity * 0.5); 
            const phaseShift = (totalPhase / (2 * Math.PI)) * 0.2;
            tempColor.offsetHSL(phaseShift, 0, 0);
            tempColor.lerp(new THREE.Color(0xffffff), totalSuperposition * 0.3);
        }
        meshRef.current.setColorAt(i, tempColor);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) {
        meshRef.current.instanceColor.needsUpdate = true;
    }
  });

  return (
    <instancedMesh ref={meshRef} args={[particleGeometry, particleMaterial, positions.length / 3]}>
       {/* Colors are handled via setColorAt */}
    </instancedMesh>
  );
};