import React, { memo, useRef, useState, useEffect, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Cylinder, Torus, Html, useCursor } from '@react-three/drei';
import * as THREE from 'three';
import { Howl, Howler } from 'howler';
import type { AgentState, CollapseEvent } from '../../types';

const sounds = {
    chime: new Howl({ src: ['/sounds/chime.mp3'], volume: 0.4 }),
    agentTone: new Howl({ src: ['/sounds/agent-tone.mp3'], volume: 0.3 }),
    entanglement: new Howl({ src: ['/sounds/entanglement-chime.mp3'], volume: 0.4 }),
};

const playSoundAt = (sound: Howl, position: { x: number, y: number, z: number }) => {
    const soundId = sound.play();
    sound.pos(position.x, position.y, position.z, soundId);
};

const Agent: React.FC<{ agent: AgentState }> = memo(({ agent }) => {
  const meshRef = useRef<THREE.Mesh>(null!);
  const auraRef = useRef<THREE.Mesh>(null!);
  const auraMaterialRef = useRef<THREE.MeshBasicMaterial>(null!);
  const [hovered, setHovered] = useState(false);
  const previousAgentState = useRef(agent);
  useCursor(hovered);

  // Sound effect logic
  useEffect(() => {
    const prev = previousAgentState.current;

    // High consciousness sound
    const justBecameHighConsciousness = agent.consciousness > 0.8 && prev.consciousness <= 0.8;
    if (justBecameHighConsciousness) {
        sounds.agentTone.rate(1 + (agent.consciousness - 0.8));
        playSoundAt(sounds.agentTone, agent.vibrational.position);
    }

    // Entanglement sound
    const hasEntanglement = Object.keys(agent.quantum.entanglement).length > 0;
    const prevHasEntanglement = Object.keys(prev.quantum.entanglement).length > 0;
    if (hasEntanglement && !prevHasEntanglement) {
        playSoundAt(sounds.entanglement, agent.vibrational.position);
    }
    
    // Update previous state for next render
    previousAgentState.current = agent;
  }, [agent]);


  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.position.set(agent.vibrational.position.x, agent.vibrational.position.y, agent.vibrational.position.z);
      
      const isMoksha = agent.consciousness > 0.9 && agent.karmicBurden < 0.1;
      const scale = agent.size * (isMoksha ? 1.5 : 1) * (hovered ? 1.2 : 1);
      meshRef.current.scale.set(scale, scale, scale);

      (meshRef.current.material as THREE.MeshStandardMaterial).color.set(agent.color);
      (meshRef.current.material as THREE.MeshStandardMaterial).emissive.set(agent.color);
      (meshRef.current.material as THREE.MeshStandardMaterial).emissiveIntensity = agent.consciousness * 0.5 + (isMoksha ? 0.5 : 0);
    }
    if (auraRef.current && auraMaterialRef.current) {
        auraRef.current.position.copy(meshRef.current.position);
        
        const isMoksha = agent.consciousness > 0.9 && agent.karmicBurden < 0.1;
        const baseScale = agent.size * (isMoksha ? 1.5 : 1);
        const auraScale = baseScale * 1.5 * (1 + Math.sin(Date.now() * 0.005 + agent.id) * 0.1);
        auraRef.current.scale.set(auraScale, auraScale, auraScale);
        auraMaterialRef.current.opacity = agent.consciousness * 0.3;

        // Guna color for aura
        const { sattva, rajas, tamas } = agent.gunas;
        let auraColor = '#696969'; // Tamas default
        if (sattva > rajas && sattva > tamas) {
            auraColor = '#98fb98'; // Sattva
        } else if (rajas > sattva && rajas > tamas) {
            auraColor = '#ffa500'; // Rajas
        }
        auraMaterialRef.current.color.set(auraColor);
    }
  });

  const { sattva, rajas, tamas } = agent.gunas;
  const dominantGuna = Math.max(sattva, rajas, tamas);
  const gunaLabel = dominantGuna === sattva ? 'Sattva' : dominantGuna === rajas ? 'Rajas' : 'Tamas';


  return (
    <>
      <mesh 
        ref={meshRef}
        onPointerOver={(e) => { e.stopPropagation(); setHovered(true); }}
        onPointerOut={(e) => setHovered(false)}
      >
        <icosahedronGeometry args={[0.5, 1]} />
        <meshStandardMaterial roughness={0.2} metalness={0.5} />
        {hovered && (
             <Html
                position={[0, agent.size * 0.8, 0]}
                wrapperClass="pointer-events-none"
                center
                distanceFactor={10}
            >
                <div className="bg-black/70 text-white text-xs rounded-md p-2 w-48 text-left backdrop-blur-sm shadow-lg">
                    <p className="font-bold border-b border-white/20 pb-1 mb-1">Agent {agent.id}</p>
                    <p>Consciousness: {agent.consciousness.toFixed(3)}</p>
                    <p>Dominant Guna: {gunaLabel} ({dominantGuna.toFixed(2)})</p>
                    <p>Karma: {agent.karmicBurden.toFixed(3)}</p>
                    <p>Superposition: {agent.quantum.superposition.toFixed(3)}</p>
                    <p>Phase: {agent.quantum.phase.toFixed(3)}</p>
                </div>
            </Html>
        )}
      </mesh>
      <mesh ref={auraRef}>
         <icosahedronGeometry args={[0.5, 1]} />
         <meshBasicMaterial ref={auraMaterialRef} transparent blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>
    </>
  );
});

const EntanglementLine: React.FC<{ start: THREE.Vector3; end: THREE.Vector3; strength: number }> = ({ start, end, strength }) => {
    const lineRef = useRef<THREE.Mesh>(null!);
    const length = start.distanceTo(end);
    const midPoint = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);
  
    useFrame(({ clock }) => {
        if (lineRef.current) {
            lineRef.current.position.copy(midPoint);
            lineRef.current.lookAt(end);
            (lineRef.current.material as THREE.MeshBasicMaterial).opacity = strength * 0.5;
            const pulse = 0.8 + Math.sin(clock.getElapsedTime() * 5 + length) * 0.2;
            lineRef.current.scale.set(pulse, pulse, 1);
        }
    });

    return (
        <Cylinder ref={lineRef} args={[0.02 * strength, 0.02 * strength, length, 8]}>
            <meshBasicMaterial color="#a78bfa" transparent depthWrite={false} blending={THREE.AdditiveBlending} />
        </Cylinder>
    );
};

const CollapseRipple: React.FC<{ event: CollapseEvent }> = ({ event }) => {
    const torusRef = useRef<THREE.Mesh>(null!);
    const startTime = useMemo(() => Date.now(), [event]);
  
    useEffect(() => {
        playSoundAt(sounds.chime, event.position);
    }, [event]);

    useFrame(() => {
        if (!torusRef.current) return;
        const elapsedTime = (Date.now() - startTime) / 1000;
        const life = 1.5; // seconds
        if (elapsedTime > life) {
            torusRef.current.visible = false;
            return;
        }
        const progress = elapsedTime / life;
        const scale = progress * event.intensity * 20;
        torusRef.current.scale.set(scale, scale, scale);
        (torusRef.current.material as THREE.MeshBasicMaterial).opacity = (1 - progress) * 0.8;
    });

    return (
        <Torus ref={torusRef} position={[event.position.x, event.position.y, event.position.z]} args={[1, 0.05, 8, 32]}>
            <meshBasicMaterial color="#facc15" transparent depthWrite={false} blending={THREE.AdditiveBlending} />
        </Torus>
    );
};


interface AgentManagerProps {
  agents: AgentState[];
  collapseEvents: CollapseEvent[];
  volume: number;
}

export const AgentManager: React.FC<AgentManagerProps> = ({ agents, collapseEvents, volume }) => {
    const { camera } = useThree();
    const agentMap = useMemo(() => new Map(agents.map(a => [a.id, a])), [agents]);

    // Update global volume
    useEffect(() => {
      Howler.volume(volume);
    }, [volume]);
    
    // Update listener position for spatial audio
    useFrame(() => {
        const { x, y, z } = camera.position;
        const worldDirection = new THREE.Vector3();
        camera.getWorldDirection(worldDirection);
        const { x: fx, y: fy, z: fz } = worldDirection;
        const { x: ux, y: uy, z: uz } = camera.up;
        Howler.pos(x, y, z);
        Howler.orientation(fx, fy, fz, ux, uy, uz);
    });

    const entanglementPairs = useMemo(() => {
        const pairs: {agentA: AgentState, agentB: AgentState, strength: number}[] = [];
        agents.forEach(agentA => {
            Object.entries(agentA.quantum.entanglement).forEach(([otherIdStr, strength]) => {
                const otherId = parseInt(otherIdStr);
                if (agentA.id < otherId) { // Avoid duplicates and self-entanglement
                    const agentB = agentMap.get(otherId);
                    if (agentB) {
                        pairs.push({ agentA, agentB, strength });
                    }
                }
            });
        });
        return pairs;
    }, [agents, agentMap]);

    return (
        <group>
            {agents.map((agent) => (
                <Agent key={agent.id} agent={agent} />
            ))}
            {entanglementPairs.map(({ agentA, agentB, strength }, index) => (
                <EntanglementLine 
                    key={`${agentA.id}-${agentB.id}-${index}`}
                    start={new THREE.Vector3(agentA.vibrational.position.x, agentA.vibrational.position.y, agentA.vibrational.position.z)}
                    end={new THREE.Vector3(agentB.vibrational.position.x, agentB.vibrational.position.y, agentB.vibrational.position.z)}
                    strength={strength}
                />
            ))}
            {collapseEvents.map((event, index) => (
                <CollapseRipple key={`${event.timestamp}-${event.agentId}-${index}`} event={event} />
            ))}
        </group>
    );
};