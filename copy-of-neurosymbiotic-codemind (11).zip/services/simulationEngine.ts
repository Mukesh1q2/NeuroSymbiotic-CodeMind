import type { AgentState, SimulationParams, CollapseEvent, VibrationalState, QuantumState, Vector3, MemoryTrace } from '../types';

// Simplified matrix and vector math helpers
const getDistance = (v1: Vector3, v2: Vector3): number => {
  const dx = v1.x - v2.x;
  const dy = v1.y - v2.y;
  const dz = v1.z - v2.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
};

const subVectors = (v1: Vector3, v2: Vector3): Vector3 => ({ x: v1.x - v2.x, y: v1.y - v2.y, z: v1.z - v2.z });
const addVectors = (v1: Vector3, v2: Vector3): Vector3 => ({ x: v1.x + v2.x, y: v1.y + v2.y, z: v1.z + v2.z });
const multiplyScalar = (v: Vector3, s: number): Vector3 => ({ x: v.x * s, y: v.y * s, z: v.z * s });
const lengthSq = (v: Vector3): number => v.x * v.x + v.y * v.y + v.z * v.z;
const normalize = (v: Vector3): Vector3 => {
    const len = Math.sqrt(lengthSq(v));
    if (len > 0) {
        return multiplyScalar(v, 1 / len);
    }
    return v;
};


export class SimulationEngine {
  private time: number = 0;
  private nextAgentId: number = 0;

  constructor() {}

  createAgent(id: number, params: SimulationParams): AgentState {
    this.nextAgentId = Math.max(this.nextAgentId, id + 1);
    const position: Vector3 = {
      x: (Math.random() - 0.5) * 40,
      y: (Math.random() - 0.5) * 20,
      z: (Math.random() - 0.5) * 40,
    };
    return {
      id,
      vibrational: {
        position,
        momentum: { x: 0, y: 0, z: 0 },
        resonance: Math.random() * 0.5 + 0.5,
        amplitude: Math.random() * 2 + 1,
        frequency: Math.random() * 0.1 + 0.05,
        phase: Math.random() * Math.PI * 2,
        entropy: Math.random(),
      },
      quantum: {
        rho: [[0.25, 0], [0, 0.25]], // Simplified 2x2 density matrix
        awareness: Math.random() * 0.8 + 0.2,
        coherence: Math.random() * 0.6 + 0.4,
        entanglement: {},
        superposition: Math.random(),
        phase: Math.random() * Math.PI * 2,
      },
      consciousness: 0.5,
      memory: [],
      lineage: [],
      color: `hsl(${Math.random() * 360}, 100%, 70%)`,
      size: 1.0,
      energy: Math.random() * 0.5 + 0.5,
      birthTime: this.time,
      lastCollapseTime: this.time,
      interactionCount: 0,
      karmicBurden: 0,
      gunas: { sattva: 0.33, rajas: 0.33, tamas: 0.34 },
    };
  }
  
  step(agents: AgentState[], params: SimulationParams): { updatedAgents: AgentState[]; newCollapseEvents: CollapseEvent[] } {
    this.time += 1;
    const newCollapseEvents: CollapseEvent[] = [];
    
    // Apply forces first to influence momentum
    const agentsWithForces = this.applyQuantumForces(agents, params);

    const updatedAgents = agentsWithForces.map(agent => {
      const newAgent = this.updateAgent(agent, agents, params);
      const collapseEvent = this.checkForCollapse(newAgent, agent, params);
      if (collapseEvent) {
        newCollapseEvents.push(collapseEvent);
        newAgent.lineage.push(collapseEvent);
        newAgent.lastCollapseTime = this.time;
        newAgent.quantum.coherence = 1.0; // Reset coherence post-collapse
        newAgent.memory.push(collapseEvent.memory);
        newAgent.karmicBurden += 0.1; // Increase karmic burden on collapse
      }
      return newAgent;
    });

    this.processInteractions(updatedAgents, params);

    return { updatedAgents, newCollapseEvents };
  }

  private applyQuantumForces(agents: AgentState[], params: SimulationParams): AgentState[] {
    const interactionForceRangeSq = 100; // squared
    return agents.map((agent, i) => {
      let totalForce: Vector3 = { x: 0, y: 0, z: 0 };
      for (let j = 0; j < agents.length; j++) {
        if (i === j) continue;
        const otherAgent = agents[j];
        const distVec = subVectors(otherAgent.vibrational.position, agent.vibrational.position);
        const distSq = lengthSq(distVec);

        if (distSq > 0.001 && distSq < interactionForceRangeSq) {
          const coherenceFactor = (agent.quantum.coherence + otherAgent.quantum.coherence) / 2;
          // Attraction proportional to coherence
          const attraction = (coherenceFactor * 0.01) / distSq;
          // Repulsion for low coherence (inversely proportional)
          const repulsion = (1 - coherenceFactor) * 0.02 / distSq;
          const forceMag = attraction - repulsion;
          const forceVec = multiplyScalar(normalize(distVec), forceMag);
          totalForce = addVectors(totalForce, forceVec);
        }
      }
      const newMomentum = addVectors(agent.vibrational.momentum, totalForce);
      return { ...agent, vibrational: { ...agent.vibrational, momentum: newMomentum } };
    });
  }

  private updateAgent(agent: AgentState, allAgents: AgentState[], params: SimulationParams): AgentState {
    const newAgent = JSON.parse(JSON.stringify(agent));
    newAgent.vibrational = this.updateVibrationalField(agent, allAgents, params);
    newAgent.quantum = this.updateQuantumState(agent, allAgents, params);
    newAgent.consciousness = this.calculateConsciousness(newAgent.quantum, newAgent.vibrational);
    newAgent.energy = this.calculateEnergy(newAgent);
    newAgent.size = 0.6 + newAgent.consciousness * 0.8;
    
    // Update memory
    newAgent.memory = agent.memory
      .map(m => ({ ...m, intensity: m.intensity * (1 - params.memoryDecay) }))
      .filter(m => m.intensity > 0.01);
      
    // Update karmic burden
    newAgent.karmicBurden += (1 - newAgent.quantum.coherence) * 0.001; // Increase with decoherence
    newAgent.karmicBurden *= (1 - params.vasanaDecay); // Decay over time
    newAgent.karmicBurden = Math.max(0, newAgent.karmicBurden);

    // Update gunas
    const sattva = newAgent.vibrational.resonance * newAgent.quantum.coherence;
    const rajas = newAgent.vibrational.entropy * (1 - newAgent.quantum.coherence);
    const tamas = (1 - newAgent.consciousness);
    const total = sattva + rajas + tamas + 0.0001;
    newAgent.gunas = { sattva: sattva / total, rajas: rajas / total, tamas: tamas / total };
      
    return newAgent;
  }

  private updateVibrationalField(agent: AgentState, allAgents: AgentState[], params: SimulationParams): VibrationalState {
    const newVibrational = { ...agent.vibrational };
    const { position, momentum } = newVibrational;
    const { classicalDamping, fieldStrength, interactionRange, quantumDiffusion, entropyRate, sankalpaStrength } = params;

    position.x += momentum.x * 0.01;
    position.y += momentum.y * 0.01;
    position.z += momentum.z * 0.01;
    momentum.x *= (1 - classicalDamping);
    momentum.y *= (1 - classicalDamping);
    momentum.z *= (1 - classicalDamping);

    // Sankalpa strength pulls agents towards center
    if (sankalpaStrength > 0) {
        momentum.x -= position.x * 0.001 * sankalpaStrength;
        momentum.y -= position.y * 0.001 * sankalpaStrength;
        momentum.z -= position.z * 0.001 * sankalpaStrength;
    }

    // Add quantum diffusion for dreamlike state
    if (quantumDiffusion > 0) {
        momentum.x += (Math.random() - 0.5) * quantumDiffusion * 0.2;
        momentum.y += (Math.random() - 0.5) * quantumDiffusion * 0.2;
        momentum.z += (Math.random() - 0.5) * quantumDiffusion * 0.2;
    }

    // This is a simple field force, distinct from agent-agent forces.
    allAgents.forEach(other => {
      if (other.id === agent.id) return;
      const distance = getDistance(position, other.vibrational.position);
      if (distance < interactionRange && distance > 0.1) {
        const force = (fieldStrength / (distance * distance + 0.1)) * other.vibrational.resonance;
        const dx = (other.vibrational.position.x - position.x) / distance;
        const dy = (other.vibrational.position.y - position.y) / distance;
        const dz = (other.vibrational.position.z - position.z) / distance;
        momentum.x += force * dx * 0.01;
        momentum.y += force * dy * 0.01;
        momentum.z += force * dz * 0.01;
      }
    });

    newVibrational.phase = (newVibrational.phase + newVibrational.frequency) % (2 * Math.PI);
    newVibrational.resonance = 0.5 + 0.5 * Math.sin(newVibrational.phase);
    
    // Update entropy
    newVibrational.entropy += (Math.random() - 0.5) * entropyRate * 0.1;
    newVibrational.entropy = Math.max(0, Math.min(1, newVibrational.entropy));
    
    return newVibrational;
  }

  private updateQuantumState(agent: AgentState, allAgents: AgentState[], params: SimulationParams): QuantumState {
    const newQuantum = { ...agent.quantum };
    const { decoherenceRate, awarenessScaling, entanglementStrength, interactionRange } = params;

    // Simulate decoherence
    newQuantum.coherence -= decoherenceRate * agent.vibrational.resonance * 0.1;
    newQuantum.coherence = Math.max(0, newQuantum.coherence);

    newQuantum.awareness = Math.min(1, newQuantum.coherence * awarenessScaling * (1 + agent.vibrational.resonance * 0.3));

    // Evolve superposition and phase
    newQuantum.superposition = Math.max(0, Math.min(1, newQuantum.superposition + (Math.random() - 0.5) * 0.02));
    newQuantum.phase = (newQuantum.phase + newQuantum.coherence * 0.1) % (Math.PI * 2);

    allAgents.forEach(other => {
        if (other.id === agent.id) return;
        const distance = getDistance(agent.vibrational.position, other.vibrational.position);
        if (distance < interactionRange * 0.7 && distance > 0) {
            const potential = entanglementStrength / (distance + 1);
            newQuantum.entanglement[other.id] = Math.min(1, (newQuantum.entanglement[other.id] || 0) + potential * 0.01);
        } else if (newQuantum.entanglement[other.id]) {
            newQuantum.entanglement[other.id] *= 0.98; // Decay
            if (newQuantum.entanglement[other.id] < 0.01) {
                delete newQuantum.entanglement[other.id];
            }
        }
    });
    return newQuantum;
  }

  private checkForCollapse(newAgent: AgentState, oldAgent: AgentState, params: SimulationParams): CollapseEvent | null {
    const randomCollapseChance = (params.quantumDiffusion || 0) * 0.05;
    if (newAgent.quantum.coherence < params.collapseThreshold || (params.quantumDiffusion > 0 && Math.random() < randomCollapseChance)) {
      const intensity = (1 - newAgent.quantum.coherence) * newAgent.consciousness;
      const memory: MemoryTrace = {
        position: { ...newAgent.vibrational.position },
        intensity: intensity,
        timestamp: this.time,
      };
      return {
        agentId: newAgent.id,
        position: { ...newAgent.vibrational.position },
        intensity,
        timestamp: this.time,
        memory,
      };
    }
    return null;
  }

  private processInteractions(agents: AgentState[], params: SimulationParams): void {
      for (let i = 0; i < agents.length; i++) {
          for (let j = i + 1; j < agents.length; j++) {
              const agentA = agents[i];
              const agentB = agents[j];
              const distance = getDistance(agentA.vibrational.position, agentB.vibrational.position);
              
              const entanglementStrength = agentA.quantum.entanglement[agentB.id] || 0;

              if (distance < params.interactionRange * 0.2 || entanglementStrength > 0.1) {
                  agentA.interactionCount++;
                  agentB.interactionCount++;

                  // Simple energy exchange
                  const energyDiff = agentA.energy - agentB.energy;
                  agentA.energy -= energyDiff * 0.001;
                  agentB.energy += energyDiff * 0.001;
                  
                  // HyperEntanglement state sync (if entangled)
                  if (entanglementStrength > 0.1) {
                      const weight = entanglementStrength * 0.5; // How much to sync per step
                      const avgCoherence = (agentA.quantum.coherence + agentB.quantum.coherence) / 2;
                      const avgAwareness = (agentA.quantum.awareness + agentB.quantum.awareness) / 2;
                      
                      agentA.quantum.coherence = (agentA.quantum.coherence * (1-weight)) + (avgCoherence * weight);
                      agentB.quantum.coherence = (agentB.quantum.coherence * (1-weight)) + (avgCoherence * weight);
                      
                      agentA.quantum.awareness = (agentA.quantum.awareness * (1-weight)) + (avgAwareness * weight);
                      agentB.quantum.awareness = (agentB.quantum.awareness * (1-weight)) + (avgAwareness * weight);
                  }
              }
          }
      }
  }

  private calculateConsciousness(quantum: QuantumState, vibrational: VibrationalState): number {
    const entanglementFactor = Object.keys(quantum.entanglement).length / 10;
    return Math.min(1, quantum.awareness * 0.6 + vibrational.resonance * 0.2 + entanglementFactor * 0.2);
  }

  private calculateEnergy(agent: AgentState): number {
    const momentumSq = agent.vibrational.momentum.x ** 2 + agent.vibrational.momentum.y ** 2 + agent.vibrational.momentum.z ** 2;
    const kineticEnergy = 0.5 * momentumSq;
    const potentialEnergy = agent.consciousness * agent.quantum.awareness;
    return Math.min(1, (kineticEnergy * 0.1 + potentialEnergy * 0.9));
  }
}